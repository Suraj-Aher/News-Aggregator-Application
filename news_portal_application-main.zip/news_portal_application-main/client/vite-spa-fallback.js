// This middleware will catch all requests and serve index.html
// which is necessary for client-side routing to work correctly
export default function ViteSpaFallbackPlugin() {
  return {
    name: 'vite-spa-fallback',
    configureServer(server) {
      return () => {
        server.middlewares.use((req, res, next) => {
          // If the URL doesn't point to a file extension, treat it as a client-side route
          if (!req.url.includes('.') && !req.url.startsWith('/api')) {
            req.url = '/';
          }
          next();
        });
      };
    }
  };
}
