import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Navigation } from "@/components/navigation";
import { CategoryFilter } from "@/components/category-filter";
import { NewsFilter } from "@/components/news-filter";
import { NewsCard } from "@/components/news-card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useAuth } from "@/lib/auth.tsx";
import { apiClient } from "@/lib/apiClient";
import { NewsArticle, NewsResponse } from "@/lib/api";

export default function NewsPortal() {
  const { isAuthenticated } = useAuth();
  const [location, setLocation] = useLocation();
  // Parse URL query parameters
  const getInitialCategory = () => {
    if (typeof window !== 'undefined') {
      const searchParams = new URLSearchParams(window.location.search);
      const categoryParam = searchParams.get('category');
      return categoryParam || "all";
    }
    return "all";
  };
  
  const [activeCategory, setActiveCategory] = useState(getInitialCategory());
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const [fromDate, setFromDate] = useState<Date | undefined>(undefined);
  const [toDate, setToDate] = useState<Date | undefined>(undefined);
  const [selectedCountry, setSelectedCountry] = useState("in"); // Default to India
  const pageSize = 12;

  const { data: newsResponse, isLoading, error } = useQuery<NewsResponse>({
    queryKey: ["news", activeCategory, currentPage, searchTerm, fromDate, toDate, selectedCountry],
    queryFn: () => apiClient.getNews({
      categoryName: activeCategory === "all" ? undefined : activeCategory,
      page: currentPage,
      pageSize: pageSize,
      query: searchTerm || undefined,
      fromDate: fromDate ? fromDate.toISOString().split('T')[0] : undefined,
      toDate: toDate ? toDate.toISOString().split('T')[0] : undefined,
      country: selectedCountry,
    }),
    enabled: isAuthenticated,
  });

  const articles = newsResponse?.articles || [];
  const totalPages = newsResponse?.totalPages || 1;


  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);
  

  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const categoryParam = searchParams.get('category');
    if (categoryParam) {
      setActiveCategory(categoryParam);
      setCurrentPage(1); 
    }
  }, [location]);


  if (!isAuthenticated) {
    return <div>Redirecting...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 overflow-x-hidden w-full">
      <Navigation />
      
 

      {/* Category Filter */}
      <CategoryFilter
        activeCategory={activeCategory}
        onCategoryChange={(category) => {
          setActiveCategory(category);
          setCurrentPage(1);  // Reset to first page when changing category
        }}
      />

           {/* Hero Section */}
      <div className="bg-gradient-to-r from-primary to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold sm:text-5xl md:text-6xl">Stay Informed</h1>
            <p className="mt-3 max-w-md mx-auto text-xl text-blue-100 sm:text-2xl md:mt-5 md:max-w-3xl">
              Get the latest news from around the world, updated in real-time
            </p>
          </div>
        </div>
      </div>

      {/* Search and Date Filter */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <NewsFilter 
          onSearch={(term) => {
            setSearchTerm(term);
            setCurrentPage(1);  // Reset to first page when searching
          }} 
          onDateChange={(from, to) => {
            setFromDate(from);
            setToDate(to);
            setCurrentPage(1);  // Reset to first page when changing dates
          }}
          onCountryChange={(country) => {
            setSelectedCountry(country);
            setCurrentPage(1);  // Reset to first page when changing country
          }}
          selectedCountry={selectedCountry}
        />
      </div>


      {/* News Articles Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-md overflow-hidden animate-pulse">
                <div className="w-full h-48 bg-gray-300" />
                <div className="p-6">
                  <div className="h-4 bg-gray-300 rounded mb-2" />
                  <div className="h-6 bg-gray-300 rounded mb-2" />
                  <div className="h-16 bg-gray-300 rounded mb-4" />
                  <div className="flex justify-between">
                    <div className="h-8 w-24 bg-gray-300 rounded" />
                    <div className="h-8 w-20 bg-gray-300 rounded" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-red-600">Failed to load articles. Please try again.</p>
          </div>
        ) : articles.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <div className="mb-4 text-orange-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">No articles found</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm ? `No articles match the search "${searchTerm}"` : 
              activeCategory !== "all" ? `No articles found in the ${activeCategory} category` : 
              'No articles available with the current filters'}
            </p>
            <Button
              variant="outline"
              onClick={() => {
                setActiveCategory("all");
                setSearchTerm("");
                setFromDate(undefined);
                setToDate(undefined);
                setCurrentPage(1);
              }}
            >
              Clear All Filters
            </Button>
          </div>
        ) : (
          <>
            <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div className="text-sm text-gray-600 mb-4 sm:mb-0">
                Showing {articles.length} of {newsResponse?.totalCount || 0} articles
                {activeCategory !== "all" && ` in ${activeCategory}`}
                {searchTerm && ` matching "${searchTerm}"`}
              </div>
              <div className="text-sm text-gray-600">
                Page {currentPage} of {totalPages}
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {articles.map((article) => (
                <NewsCard key={article.id} article={article} />
              ))}
            </div>
          </>
        )}

        {/* Pagination */}
        {!isLoading && !error && articles.length > 0 && totalPages > 1 && (
          <div className="mt-8 flex justify-center">
            <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px flex-wrap justify-center gap-y-2 p-2">
              <Button
                variant="outline"
                size="sm"
                className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(currentPage - 1)}
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              
              {(() => {
                const pageButtons = [];
                const maxVisiblePages = 5;
                const halfVisible = Math.floor(maxVisiblePages / 2);
                
                let startPage = Math.max(1, currentPage - halfVisible);
                let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
                
                // Adjust start page if we're near the end
                if (endPage - startPage + 1 < maxVisiblePages) {
                  startPage = Math.max(1, endPage - maxVisiblePages + 1);
                }
                
                // First page button
                if (startPage > 1) {
                  pageButtons.push(
                    <Button
                      key="first"
                      variant="outline"
                      size="sm"
                      className="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 relative inline-flex items-center px-4 py-2 border text-sm font-medium"
                      onClick={() => setCurrentPage(1)}
                    >
                      1
                    </Button>
                  );
                  
                  if (startPage > 2) {
                    pageButtons.push(
                      <span key="ellipsis-start" className="relative inline-flex items-center px-3 py-2 border border-gray-300 bg-white text-gray-700">
                        ...
                      </span>
                    );
                  }
                }
                
                // Page buttons
                for (let i = startPage; i <= endPage; i++) {
                  const isCurrentPage = i === currentPage;
                  pageButtons.push(
                    <Button
                      key={i}
                      variant={isCurrentPage ? "default" : "outline"}
                      size="sm"
                      className={isCurrentPage 
                        ? "bg-primary border-primary text-white relative inline-flex items-center px-4 py-2 border text-sm font-medium"
                        : "bg-white border-gray-300 text-gray-500 hover:bg-gray-50 relative inline-flex items-center px-4 py-2 border text-sm font-medium"
                      }
                      onClick={() => setCurrentPage(i)}
                    >
                      {i}
                    </Button>
                  );
                }
                
                // Last page button
                if (endPage < totalPages) {
                  if (endPage < totalPages - 1) {
                    pageButtons.push(
                      <span key="ellipsis-end" className="relative inline-flex items-center px-3 py-2 border border-gray-300 bg-white text-gray-700">
                        ...
                      </span>
                    );
                  }
                  
                  pageButtons.push(
                    <Button
                      key="last"
                      variant="outline"
                      size="sm"
                      className="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 relative inline-flex items-center px-4 py-2 border text-sm font-medium"
                      onClick={() => setCurrentPage(totalPages)}
                    >
                      {totalPages}
                    </Button>
                  );
                }
                
                return pageButtons;
              })()}
              
              <Button
                variant="outline"
                size="sm"
                className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(currentPage + 1)}
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </nav>
          </div>
        )}
      </div>
    </div>
  );
}
