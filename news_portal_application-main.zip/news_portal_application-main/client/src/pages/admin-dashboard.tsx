import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Navigation } from "@/components/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Newspaper, 
  Users, 
  Eye, 
  TrendingUp, 
  Plus, 
  Edit, 
  Trash2, 
  Settings, 
  Home,
  List,
  BarChart3,
  Tag,
  BookOpen,
  RefreshCw,
  Search,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { useAuth } from "@/lib/auth.tsx";
import { apiClient } from "@/lib/apiClient";
import { NewsArticle, NewsResponse, DashboardStats, CategoryStat, User as ApiUser, UserStats, Category as ApiCategory, CreateCategory, UpdateCategory, UpdateUser } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

interface LocalCategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
  color?: string;
}

interface NewArticle {
  title: string;
  description: string;
  content: string;
  category: string;
  author: string;
  source: string;
  url: string;
  image?: string;
}

const categories: LocalCategory[] = [
  { id: "technology", name: "Technology", slug: "technology", icon: "💻", color: "blue" },
  { id: "business", name: "Business", slug: "business", icon: "💼", color: "green" },
  { id: "sports", name: "Sports", slug: "sports", icon: "⚽", color: "orange" },
  { id: "health", name: "Health", slug: "health", icon: "🏥", color: "red" },
  { id: "science", name: "Science", slug: "science", icon: "🔬", color: "purple" },
  { id: "entertainment", name: "Entertainment", slug: "entertainment", icon: "🎬", color: "pink" },
];

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Sidebar state
  const [activeTab, setActiveTab] = useState("dashboard");
  
  // Add error state for debugging
  const [hasError, setHasError] = useState(false);
  
  // Error boundary effect
  useEffect(() => {
    const handleError = (error: ErrorEvent) => {
      console.error("Global error caught:", error);
      setHasError(true);
    };
    
    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);
  
  // If there's an error, show error state
  if (hasError) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full">
          <h2 className="text-xl font-bold text-red-600 mb-4">Something went wrong</h2>
          <p className="text-gray-700 mb-4">
            There was an error loading the admin dashboard. Please try refreshing the page.
          </p>
          <button 
            onClick={() => window.location.reload()}
            className="w-full px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Refresh Page
          </button>
        </div>
      </div>
    );
  }
  
  // Dialog states
  const [isAddArticleOpen, setIsAddArticleOpen] = useState(false);
  const [isAddCategoryOpen, setIsAddCategoryOpen] = useState(false);
  const [isEditCategoryOpen, setIsEditCategoryOpen] = useState(false);
  const [isEditUserOpen, setIsEditUserOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<ApiCategory | null>(null);
  const [selectedUser, setSelectedUser] = useState<ApiUser | null>(null);
  
  // Form states
  const [newArticle, setNewArticle] = useState<NewArticle>({
    title: "",
    description: "",
    content: "",
    category: "",
    author: "",
    source: "",
    url: "",
    image: ""
  });
  
  const [newCategory, setNewCategory] = useState<Partial<LocalCategory>>({
    name: "",
    slug: "",
    description: "",
    icon: "",
    color: "blue"
  });

  const [editCategory, setEditCategory] = useState<UpdateCategory>({
    name: "",
    description: "",
    icon: "",
    color: "",
    isActive: true
  });

  const [editUser, setEditUser] = useState<UpdateUser>({
    firstName: "",
    lastName: "",
    role: ""
  });

  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    } else if (user?.role !== "Admin") {
      setLocation("/news");
    }
  }, [isAuthenticated, user, setLocation]);

  // Data queries
  const { data: newsResponse } = useQuery<NewsResponse>({
    queryKey: ["admin-news"],
    queryFn: () => apiClient.getNews({ page: 1, pageSize: 20 }),
    enabled: isAuthenticated && user?.role === "Admin",
  });

  const { data: dashboardStats, isLoading: statsLoading, refetch: refetchStats } = useQuery<DashboardStats>({
    queryKey: ["dashboard-stats"],
    queryFn: () => apiClient.getDashboardStats(),
    enabled: isAuthenticated && user?.role === "Admin",
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  const { data: users, isLoading: usersLoading, refetch: refetchUsers } = useQuery<ApiUser[]>({
    queryKey: ["admin-users"],
    queryFn: () => apiClient.getUsers(),
    enabled: isAuthenticated && user?.role === "Admin",
  });

  const { data: userStats, isLoading: userStatsLoading } = useQuery<UserStats>({
    queryKey: ["user-stats"],
    queryFn: () => apiClient.getUserStats(),
    enabled: isAuthenticated && user?.role === "Admin",
    refetchInterval: 60000, // Refetch every minute
  });

  const { data: apiCategories, isLoading: categoriesLoading, refetch: refetchCategories } = useQuery<ApiCategory[]>({
    queryKey: ["admin-categories"],
    queryFn: () => apiClient.getCategoriesWithStats(),
    enabled: isAuthenticated && user?.role === "Admin",
  });

  const articles = newsResponse?.articles || [];

  // News sync mutation
  const syncNewsMutation = useMutation({
    mutationFn: (category?: string) => apiClient.syncNews(category),
    onSuccess: () => {
      toast({
        title: "News sync completed",
        description: "Successfully synced news from external API.",
      });
      refetchStats();
      queryClient.invalidateQueries({ queryKey: ["admin-news"] });
    },
    onError: (error) => {
      toast({
        title: "Sync failed",
        description: error instanceof Error ? error.message : "Failed to sync news",
        variant: "destructive",
      });
    },
  });

  // Mutations
  const addArticleMutation = useMutation({
    mutationFn: async (article: NewArticle) => {
      // This would be an API call to create article
      // For now, we'll simulate it
      return Promise.resolve(article);
    },
    onSuccess: () => {
      toast({
        title: "Article added",
        description: "The article has been successfully added.",
      });
      setIsAddArticleOpen(false);
      setNewArticle({
        title: "",
        description: "",
        content: "",
        category: "",
        author: "",
        source: "",
        url: "",
        image: ""
      });
      queryClient.invalidateQueries({ queryKey: ["admin-news"] });
    },
  });

  // Category mutations
  const createCategoryMutation = useMutation({
    mutationFn: (categoryData: CreateCategory) => apiClient.createCategory(categoryData),
    onSuccess: () => {
      toast({
        title: "Category created",
        description: "The category has been successfully created.",
      });
      setIsAddCategoryOpen(false);
      setNewCategory({ name: "", slug: "", description: "", icon: "", color: "blue" });
      refetchCategories();
      refetchStats();
    },
    onError: (error) => {
      toast({
        title: "Failed to create category",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });

  const updateCategoryMutation = useMutation({
    mutationFn: ({ id, categoryData }: { id: number; categoryData: UpdateCategory }) => 
      apiClient.updateCategory(id, categoryData),
    onSuccess: () => {
      toast({
        title: "Category updated",
        description: "The category has been successfully updated.",
      });
      setIsEditCategoryOpen(false);
      setSelectedCategory(null);
      setEditCategory({ name: "", description: "", icon: "", color: "", isActive: true });
      refetchCategories();
      refetchStats();
      queryClient.invalidateQueries({ queryKey: ["admin-news"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to update category",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });

  const deleteCategoryMutation = useMutation({
    mutationFn: (id: number) => 
      apiClient.deleteCategory(id),
    onSuccess: (data) => {
      toast({
        title: "Category deleted",
        description: data.message,
      });
      refetchCategories();
      refetchStats();
      queryClient.invalidateQueries({ queryKey: ["admin-news"] });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete category",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });

  // User mutations
  const updateUserMutation = useMutation({
    mutationFn: ({ id, userData }: { id: number; userData: UpdateUser }) => 
      apiClient.updateUser(id, userData),
    onSuccess: () => {
      toast({
        title: "User updated",
        description: "The user has been successfully updated.",
      });
      setIsEditUserOpen(false);
      setSelectedUser(null);
      setEditUser({ firstName: "", lastName: "", role: "" });
      refetchUsers();
    },
    onError: (error) => {
      toast({
        title: "Failed to update user",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });

  const deactivateUserMutation = useMutation({
    mutationFn: (id: number) => apiClient.deactivateUser(id),
    onSuccess: (data) => {
      toast({
        title: "User deactivated",
        description: data.message,
      });
      refetchUsers();
    },
    onError: (error) => {
      toast({
        title: "Failed to deactivate user",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });

  if (!isAuthenticated || user?.role !== "Admin") {
    return null;
  }

  const sidebarItems = [
    { id: "dashboard", label: "Dashboard", icon: Home },
    { id: "articles", label: "Articles", icon: Newspaper },
    { id: "categories", label: "Categories", icon: Tag },
    { id: "users", label: "Users", icon: Users },
  ];

  const renderDashboard = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium text-gray-900">Dashboard Overview</h3>
        <Button 
          onClick={() => syncNewsMutation.mutate(undefined)}
          disabled={syncNewsMutation.isPending}
          variant="outline"
          size="sm"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${syncNewsMutation.isPending ? 'animate-spin' : ''}`} />
          Sync News
        </Button>
      </div>
      
      {statsLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-8 w-8 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Newspaper className="h-8 w-8 text-blue-600" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Total Articles</dt>
                    <dd className="text-2xl font-bold text-gray-900">{dashboardStats?.totalArticles || 0}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Tag className="h-8 w-8 text-green-600" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Categories</dt>
                    <dd className="text-2xl font-bold text-gray-900">{dashboardStats?.totalCategories || 0}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Eye className="h-8 w-8 text-purple-600" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Today's Articles</dt>
                    <dd className="text-2xl font-bold text-gray-900">{dashboardStats?.articlesToday || 0}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <TrendingUp className="h-8 w-8 text-orange-600" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">This Week</dt>
                    <dd className="text-2xl font-bold text-gray-900">{dashboardStats?.articlesThisWeek || 0}</dd>
                  </dl>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
      
      {/* Category Statistics */}
      {dashboardStats?.categoryStats && dashboardStats.categoryStats.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Category Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {dashboardStats.categoryStats.map((stat) => (
                <div key={stat.categoryName || stat.categoryId} className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline" className="capitalize">
                      {stat.categoryName || `Category ${stat.categoryId}`}
                    </Badge>
                  </div>
                  <div className="text-sm font-medium">
                    {stat.count} articles
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Recent Articles */}
      {dashboardStats?.recentArticles && dashboardStats.recentArticles.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Articles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {dashboardStats.recentArticles.map((article) => (
                <div key={article.id} className="border-b border-gray-200 pb-4 last:border-b-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="text-sm font-medium text-gray-900 line-clamp-2">
                        {article.title}
                      </h4>
                      <p className="text-sm text-gray-500 mt-1">
                        {article.source} • {new Date(article.publishedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <Badge variant="outline" className="ml-2 capitalize">
                      {article.categoryName || 'Uncategorized'}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button 
              onClick={() => setIsAddArticleOpen(true)}
              className="bg-blue-600 text-white hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Article
            </Button>
            <Button 
              variant="outline"
              onClick={() => setActiveTab("categories")}
            >
              <Tag className="w-4 h-4 mr-2" />
              Manage Categories
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
  // State for articles pagination
  const [articlesPage, setArticlesPage] = useState(1);
  const [articlesPageSize, setArticlesPageSize] = useState(10);
  const [articleSearchTerm, setArticleSearchTerm] = useState("");
  const [articleCategoryFilter, setArticleCategoryFilter] = useState<string | undefined>(undefined);
  
  // Query for paginated articles
  const { data: paginatedArticles, isLoading: articlesLoading, isError: articlesError } = useQuery<NewsResponse>({
    queryKey: ["admin-articles", articlesPage, articlesPageSize, articleSearchTerm, articleCategoryFilter],
    queryFn: () => apiClient.getNews({
      page: articlesPage, 
      pageSize: articlesPageSize,
      query: articleSearchTerm || undefined,
      categoryName: articleCategoryFilter
    }),
    enabled: isAuthenticated && user?.role === "Admin" && activeTab === "articles",
    retry: 3, // Retry 3 times on error
    refetchOnWindowFocus: false,
    staleTime: 30000, // 30 seconds
  });

  const renderArticles = () => {
    try {
      // Use real API data
      const articleItems = paginatedArticles?.articles || [];
      const totalArticles = paginatedArticles?.totalCount || 0;
      const totalPages = paginatedArticles?.totalPages || 1;
      
      // Add console log for debugging
      console.log("Articles rendering:", { 
        articleItems: articleItems?.length, 
        isLoading: articlesLoading, 
        isError: articlesError,
        activeTab,
        paginatedArticles: !!paginatedArticles 
      });
      
      // Show error state if API failed
      if (articlesError) {
        return (
          <div className="space-y-6">
            <div className="bg-red-50 border border-red-200 rounded-md p-4">
              <h3 className="text-lg font-medium text-red-800">Unable to load articles</h3>
              <p className="text-red-700 mt-2">
                Could not connect to the backend API. Please ensure the server is running on http://localhost:5000
              </p>
              <button 
                onClick={() => window.location.reload()}
                className="mt-4 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
              >
                Retry
              </button>
            </div>
          </div>
        );
      }
      
      return (
        <div className="space-y-6 w-full overflow-x-hidden">
          {/* Debug info */}
          <div className="bg-green-50 p-4 rounded-md mb-4">
            <p className="text-sm">
              Articles loaded successfully from database: {articleItems?.length || 0} articles 
              {articlesLoading && " (Loading...)"}
            </p>
          </div>
          
          <div className="flex flex-wrap justify-between items-center gap-4">
            <h3 className="text-lg font-medium text-gray-900">Articles Management</h3>
            <div className="flex items-center gap-2">
              <Button 
                onClick={() => setIsAddArticleOpen(true)}
                className="bg-blue-600 text-white hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Article
              </Button>
              <Badge variant="outline" className="text-sm font-normal py-1">
                Total: {totalArticles}
              </Badge>
            </div>
          </div>
          
          {/* Simple table display */}
          <Card className="w-full">
            <CardHeader className="border-b bg-gray-50">
              <CardTitle>Articles List</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              {articlesLoading ? (
                <div className="text-center py-8">
                  <p>Loading articles...</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {(articleItems || []).slice(0, 5).map((article: NewsArticle) => (
                    <div key={article.id} className="border rounded-lg p-4">
                      <h4 className="font-medium text-gray-900">{article.title}</h4>
                      <p className="text-sm text-gray-600 mt-1">{article.description}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-gray-500">By {article.author}</span>
                        <Badge variant="secondary">{article.categoryName}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      );
    } catch (error) {
      console.error("Error in renderArticles:", error);
      return (
        <div className="p-8">
          <div className="bg-red-50 border border-red-200 rounded-md p-4">
            <h3 className="text-lg font-medium text-red-800">Error loading articles</h3>
            <p className="text-red-700 mt-2">
              There was an error loading the articles. Check the console for details.
            </p>
          </div>
        </div>
      );
    }
  };

  const renderCategories = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium text-gray-900">Categories Management</h3>
        <Button 
          onClick={() => setIsAddCategoryOpen(true)}
          className="bg-blue-600 text-white hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Category
        </Button>
      </div>
      
      {categoriesLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-6 w-6 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-3/4 mb-4"></div>
                  <div className="h-8 bg-gray-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : apiCategories && apiCategories.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {apiCategories.map((category) => (
            <Card key={category.name}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <span className="text-2xl mr-3">
                      {categories.find(c => c.id === category.name.toLowerCase())?.icon || '📁'}
                    </span>
                    <div>
                      <h4 className="text-lg font-medium text-gray-900 capitalize">{category.name}</h4>
                      <p className="text-sm text-gray-500">{category.slug}</p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-blue-600 hover:text-blue-900"
                      onClick={() => {
                        setSelectedCategory(category);
                        setEditCategory({
                          name: category.name,
                          description: category.description || "",
                          icon: category.icon || "",
                          color: category.color || "",
                          isActive: category.isActive
                        });
                        setIsEditCategoryOpen(true);
                      }}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-red-600 hover:text-red-900"
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete the category "${category.name}"?`)) {
                          deleteCategoryMutation.mutate(category.id);
                        }
                      }}
                      disabled={deleteCategoryMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  {category.description || "No description available"}
                </p>
                <div className="flex items-center justify-between">
                  <Badge 
                    variant="secondary" 
                    className={`bg-${categories.find(c => c.id === category.name.toLowerCase())?.color || 'gray'}-100 text-${categories.find(c => c.id === category.name.toLowerCase())?.color || 'gray'}-800`}
                  >
                    {categories.find(c => c.id === category.name.toLowerCase())?.color || 'default'}
                  </Badge>
                  <span className="text-xs text-gray-500">
                    {category.articleCount} articles
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <Tag className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No categories found</h3>
          <p className="mt-1 text-sm text-gray-500">
            Create your first category to organize articles.
          </p>
        </div>
      )}
    </div>
  );

  const renderUsers = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium text-gray-900">Users Management</h3>
        <div className="flex space-x-2">
          {userStats && (
            <div className="text-sm text-gray-500">
              {userStats.totalUsers} total users ({userStats.adminUsers} admins, {userStats.regularUsers} users)
            </div>
          )}
        </div>
      </div>
      
      {/* User Statistics Cards */}
      {userStatsLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <div className="animate-pulse">
                  <div className="h-6 bg-gray-200 rounded mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : userStats ? (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <Users className="h-6 w-6 text-blue-500 mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Total Users</p>
                  <p className="text-2xl font-bold">{userStats.totalUsers}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <Settings className="h-6 w-6 text-purple-500 mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Admins</p>
                  <p className="text-2xl font-bold">{userStats.adminUsers}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <Eye className="h-6 w-6 text-green-500 mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Today</p>
                  <p className="text-2xl font-bold">{userStats.usersToday}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <TrendingUp className="h-6 w-6 text-orange-500 mr-2" />
                <div>
                  <p className="text-sm text-gray-500">This Week</p>
                  <p className="text-2xl font-bold">{userStats.usersThisWeek}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : null}
      
      {/* Users Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Users</CardTitle>
        </CardHeader>
        <CardContent>
          {usersLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="animate-pulse flex items-center space-x-4 p-4">
                  <div className="h-10 w-10 bg-gray-200 rounded-full"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                  </div>
                  <div className="h-8 w-20 bg-gray-200 rounded"></div>
                </div>
              ))}
            </div>
          ) : users && users.length > 0 ? (
            <div className="space-y-4">
              {users.map((userItem) => (
                <div key={userItem.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-600 font-medium">
                        {userItem.firstName?.charAt(0) || userItem.username.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900">
                        {userItem.firstName && userItem.lastName 
                          ? `${userItem.firstName} ${userItem.lastName}` 
                          : userItem.username}
                      </h4>
                      <p className="text-sm text-gray-500">{userItem.email}</p>
                      <p className="text-xs text-gray-400">
                        Joined {new Date(userItem.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={userItem.role === 'Admin' ? 'default' : 'secondary'}>
                      {userItem.role}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSelectedUser(userItem);
                        setEditUser({
                          firstName: userItem.firstName || "",
                          lastName: userItem.lastName || "",
                          role: userItem.role
                        });
                        setIsEditUserOpen(true);
                      }}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    {userItem.id !== user?.id && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          if (confirm("Are you sure you want to deactivate this user?")) {
                            deactivateUserMutation.mutate(userItem.id);
                          }
                        }}
                        className="text-red-600 hover:text-red-900"
                        disabled={deactivateUserMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Users className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No users found</h3>
              <p className="mt-1 text-sm text-gray-500">
                No users are currently available.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  const renderContent = () => {
    try {
      switch (activeTab) {
        case "dashboard":
          return renderDashboard();
        case "articles":
          return renderArticles();
        case "categories":
          return renderCategories();
        case "users":
          return renderUsers();
        default:
          return renderDashboard();
      }
    } catch (error) {
      console.error("Error rendering content:", error);
      return (
        <div className="p-8">
          <div className="bg-red-50 border border-red-200 rounded-md p-4">
            <h3 className="text-lg font-medium text-red-800">Something went wrong</h3>
            <p className="text-red-700 mt-2">
              There was an error rendering this content. Please check the console for details.
            </p>
            <button 
              onClick={() => window.location.reload()}
              className="mt-4 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white shadow-sm border-r min-h-screen">
          <div className="p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Admin Panel</h2>
            <nav className="space-y-2">
              {sidebarItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      activeTab === item.id
                        ? "bg-blue-100 text-blue-700"
                        : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                    }`}
                  >
                    <Icon className="w-5 h-5 mr-3" />
                    {item.label}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8">
          {renderContent()}
        </div>
      </div>

      {/* Add Article Dialog */}
      <Dialog open={isAddArticleOpen} onOpenChange={setIsAddArticleOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Add New Article</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={newArticle.title}
                onChange={(e) => setNewArticle({ ...newArticle, title: e.target.value })}
                placeholder="Article title"
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={newArticle.description}
                onChange={(e) => setNewArticle({ ...newArticle, description: e.target.value })}
                placeholder="Brief description"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="content">Content</Label>
              <Textarea
                id="content"
                value={newArticle.content}
                onChange={(e) => setNewArticle({ ...newArticle, content: e.target.value })}
                placeholder="Article content"
                rows={6}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="category">Category</Label>
                <Select onValueChange={(value) => setNewArticle({ ...newArticle, category: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.icon} {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="author">Author</Label>
                <Input
                  id="author"
                  value={newArticle.author}
                  onChange={(e) => setNewArticle({ ...newArticle, author: e.target.value })}
                  placeholder="Author name"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="source">Source</Label>
                <Input
                  id="source"
                  value={newArticle.source}
                  onChange={(e) => setNewArticle({ ...newArticle, source: e.target.value })}
                  placeholder="News source"
                />
              </div>
              <div>
                <Label htmlFor="url">URL</Label>
                <Input
                  id="url"
                  value={newArticle.url}
                  onChange={(e) => setNewArticle({ ...newArticle, url: e.target.value })}
                  placeholder="Article URL"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="image">Image URL (optional)</Label>
              <Input
                id="image"
                value={newArticle.image}
                onChange={(e) => setNewArticle({ ...newArticle, image: e.target.value })}
                placeholder="Image URL"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" onClick={() => setIsAddArticleOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => addArticleMutation.mutate(newArticle)}
                disabled={!newArticle.title || !newArticle.content || !newArticle.category}
                className="bg-blue-600 text-white hover:bg-blue-700"
              >
                Add Article
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={isEditUserOpen} onOpenChange={setIsEditUserOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-firstName">First Name</Label>
              <Input
                id="edit-firstName"
                value={editUser.firstName}
                onChange={(e) => setEditUser({ ...editUser, firstName: e.target.value })}
                placeholder="First Name"
              />
            </div>
            <div>
              <Label htmlFor="edit-lastName">Last Name</Label>
              <Input
                id="edit-lastName"
                value={editUser.lastName}
                onChange={(e) => setEditUser({ ...editUser, lastName: e.target.value })}
                placeholder="Last Name"
              />
            </div>
            <div>
              <Label htmlFor="edit-role">Role</Label>
              <Select value={editUser.role} onValueChange={(value) => setEditUser({ ...editUser, role: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="User">User</SelectItem>
                  <SelectItem value="Admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" onClick={() => setIsEditUserOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  if (selectedUser) {
                    updateUserMutation.mutate({
                      id: selectedUser.id,
                      userData: editUser
                    });
                  }
                }}
                disabled={updateUserMutation.isPending}
                className="bg-blue-600 text-white hover:bg-blue-700"
              >
                Update User
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Category Dialog */}
      <Dialog open={isAddCategoryOpen} onOpenChange={setIsAddCategoryOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add New Category</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="category-name">Category Name</Label>
              <Input
                id="category-name"
                value={newCategory.name}
                onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                placeholder="Category Name"
              />
            </div>
            <div>
              <Label htmlFor="category-description">Description</Label>
              <Textarea
                id="category-description"
                value={newCategory.description}
                onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                placeholder="Category description"
                rows={3}
              />
            </div>
            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" onClick={() => setIsAddCategoryOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  if (newCategory.name) {
                    createCategoryMutation.mutate({
                      name: newCategory.name,
                      description: newCategory.description
                    });
                  }
                }}
                disabled={!newCategory.name || createCategoryMutation.isPending}
                className="bg-blue-600 text-white hover:bg-blue-700"
              >
                Add Category
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Category Dialog */}
      <Dialog open={isEditCategoryOpen} onOpenChange={setIsEditCategoryOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Category</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-category-name">Category Name</Label>
              <Input
                id="edit-category-name"
                value={editCategory.name}
                onChange={(e) => setEditCategory({ ...editCategory, name: e.target.value })}
                placeholder="Category Name"
              />
            </div>
            <div>
              <Label htmlFor="edit-category-description">Description</Label>
              <Textarea
                id="edit-category-description"
                value={editCategory.description}
                onChange={(e) => setEditCategory({ ...editCategory, description: e.target.value })}
                placeholder="Category description"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="edit-category-icon">Icon (Emoji)</Label>
              <Input
                id="edit-category-icon"
                value={editCategory.icon}
                onChange={(e) => setEditCategory({ ...editCategory, icon: e.target.value })}
                placeholder="📰"
              />
            </div>
            <div>
              <Label htmlFor="edit-category-color">Color</Label>
              <Input
                id="edit-category-color"
                type="color"
                value={editCategory.color}
                onChange={(e) => setEditCategory({ ...editCategory, color: e.target.value })}
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="edit-category-active"
                checked={editCategory.isActive}
                onChange={(e) => setEditCategory({ ...editCategory, isActive: e.target.checked })}
                className="rounded"
              />
              <Label htmlFor="edit-category-active">Active</Label>
            </div>
            <div className="flex justify-end space-x-2 pt-4">
              <Button variant="outline" onClick={() => setIsEditCategoryOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  if (selectedCategory && editCategory.name) {
                    updateCategoryMutation.mutate({
                      id: selectedCategory.id,
                      categoryData: editCategory
                    });
                  }
                }}
                disabled={!editCategory.name || updateCategoryMutation.isPending}
                className="bg-blue-600 text-white hover:bg-blue-700"
              >
                Update Category
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
