import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

interface Category {
  id: number;
  name: string;
  slug: string;
  icon?: string;
  color?: string;
}

interface CategoryFilterProps {
  activeCategory: string;
  onCategoryChange: (category: string) => void;
}

const getCategoryColor = (categoryName: string): string => {
  const colorMap: Record<string, string> = {
    Business: "blue-600",
    Entertainment: "purple-600",
    Health: "green-600",
    Politics: "red-600",
    Science: "indigo-600",
    Sports: "orange-600",
  };
  return colorMap[categoryName] || "gray-600";
};

export function CategoryFilter({ activeCategory, onCategoryChange }: CategoryFilterProps) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/categories");
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setCategories(data);
      } catch (error) {
        console.error("Failed to fetch categories:", error);
        // Fallback to default categories if API fails
        setCategories([
          { id: 1, name: "Business", slug: "business", icon: "📈" },
          { id: 2, name: "Entertainment", slug: "entertainment", icon: "🎬" },
          { id: 3, name: "Health", slug: "health", icon: "❤️" },
          { id: 4, name: "Politics", slug: "politics", icon: "🏛️" },
          { id: 5, name: "Science", slug: "science", icon: "🔬" },
          { id: 6, name: "Sports", slug: "sports", icon: "⚽" },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, []);

  // Update URL when category changes
  const handleCategoryChange = (category: string) => {
    onCategoryChange(category);
    
    // Update the URL without triggering a page reload
    const url = new URL(window.location.href);
    if (category === "all") {
      url.searchParams.delete('category');
    } else {
      url.searchParams.set('category', category);
    }
    
    window.history.pushState({}, '', url.toString());
  };

  if (loading) {
    return (
      <div className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex py-4 space-x-4 overflow-x-auto">
            <div className="animate-pulse bg-gray-200 h-8 w-20 rounded"></div>
            <div className="animate-pulse bg-gray-200 h-8 w-24 rounded"></div>
            <div className="animate-pulse bg-gray-200 h-8 w-16 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border-b shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex overflow-x-auto py-4 space-x-4 scrollbar-hide">
          {/* All News button */}
          <Button
            onClick={() => handleCategoryChange("all")}
            variant={activeCategory === "all" ? "default" : "secondary"}
            size="sm"
            className={`whitespace-nowrap transition-colors ${
              activeCategory === "all"
                ? "bg-primary text-white"
                : "bg-gray-100 text-gray-700 hover:bg-primary hover:text-white"
            }`}
          >
            <span className="mr-2">📰</span>
            All News
          </Button>
          
          {/* Dynamic categories from API */}
          {categories.map((category) => {
            const isActive = activeCategory === category.name;
            const colorClass = getCategoryColor(category.name);
            
            return (
              <Button
                key={category.id}
                onClick={() => handleCategoryChange(category.name)}
                variant={isActive ? "default" : "secondary"}
                size="sm"
                className={`whitespace-nowrap transition-colors ${
                  isActive
                    ? "bg-primary text-white"
                    : `bg-gray-100 text-gray-700 hover:bg-${colorClass} hover:text-white`
                }`}
              >
                <span className="mr-2">{category.icon || "📄"}</span>
                {category.name}
              </Button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
