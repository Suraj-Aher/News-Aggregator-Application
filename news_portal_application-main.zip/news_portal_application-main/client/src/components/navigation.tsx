import { useAuth } from "@/lib/auth.tsx";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { LogOut, Shield, Home } from "lucide-react";

export function Navigation() {
  const { user, logout, isAuthenticated } = useAuth();
  const [location, setLocation] = useLocation();

  const handleLogout = () => {
    logout();
    setLocation("/login");
  };

  const navigateToHome = () => {
    setLocation("/news");
  };

  const navigateToAdmin = () => {
    setLocation("/admin");
  };

  // Category navigation has been removed from the navbar

  const navigateToLogin = () => {
    setLocation("/login");
  };

  return (
    <nav className="bg-white shadow-md border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <h1 className="text-2xl font-bold text-primary cursor-pointer hover:text-primary/80 transition-colors" onClick={navigateToHome}>
                News Aggregator
              </h1>
            </div>
            {isAuthenticated && (
              <div className="hidden md:block ml-10">
                <div className="flex items-baseline space-x-4">
                  <button
                    onClick={navigateToHome}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      location === "/news"
                        ? "text-gray-900"
                        : "text-gray-500 hover:text-primary"
                    }`}
                  >
                    <Home className="inline-block w-4 h-4 mr-2" />
                    Home
                  </button>
                  
                  {/* Categories removed from navbar - now only available in filter component */}
                </div>
              </div>
            )}
          </div>

          <div className="hidden md:block">
            <div className="ml-4 flex items-center md:ml-6">
              {isAuthenticated && user ? (
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-gray-700">Welcome, {user.username}</span>
                  {user.role === "Admin" && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={navigateToAdmin}
                      className="text-gray-500 hover:text-primary"
                    >
                      <Shield className="w-4 h-4 mr-2" />
                      Admin
                    </Button>
                  )}
                  <Button
                    onClick={handleLogout}
                    className="bg-primary text-white hover:bg-primary/90"
                    size="sm"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </div>
              ) : (
                <Button
                  onClick={navigateToLogin}
                  className="bg-primary text-white hover:bg-primary/90"
                  size="sm"
                >
                  Login
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
