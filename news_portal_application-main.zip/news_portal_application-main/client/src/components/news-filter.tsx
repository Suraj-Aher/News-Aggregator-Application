import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Calendar, X, Globe } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";

interface NewsFilterProps {
  onSearch: (searchTerm: string) => void;
  onDateChange: (fromDate: Date | undefined, toDate: Date | undefined) => void;
  onCountryChange: (country: string) => void;
  selectedCountry: string;
}

export function NewsFilter({ onSearch, onDateChange, onCountryChange, selectedCountry }: NewsFilterProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [fromDate, setFromDate] = useState<Date | undefined>(undefined);
  const [toDate, setToDate] = useState<Date | undefined>(undefined);
  const [showDateFilter, setShowDateFilter] = useState(false);

  const countries = [
    { value: "us", label: "🇺🇸 United States", name: "United States" },
    { value: "gb", label: "🇬🇧 United Kingdom", name: "United Kingdom" },
    { value: "in", label: "🇮🇳 India", name: "India" },
  ];

  const getCountryDisplay = (countryCode: string) => {
    const country = countries.find(c => c.value === countryCode);
    return country?.name || "Select Country";
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchTerm);
  };

  const handleDateChange = (type: 'from' | 'to', date: Date | undefined) => {
    if (type === 'from') {
      setFromDate(date);
    } else {
      setToDate(date);
    }

    if (type === 'from' && date && toDate && date > toDate) {
      setToDate(date);
    }

    if (type === 'to' && date && fromDate && date < fromDate) {
      setFromDate(date);
    }

    onDateChange(type === 'from' ? date : fromDate, type === 'to' ? date : toDate);
  };

  const clearDates = () => {
    setFromDate(undefined);
    setToDate(undefined);
    onDateChange(undefined, undefined);
  };

  return (
    <div className="bg-white p-4 shadow-md rounded-lg my-4 border border-gray-100">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search input */}
          <form onSubmit={handleSearch} className="flex-1 flex">
            <div className="relative w-full">
              <Input
                type="text"
                placeholder="Search news..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pr-10 border-gray-300 focus:border-primary"
              />
              <Button
                type="submit"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full text-gray-500 hover:text-primary"
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </form>

          {/* Country Filter */}
          <div className="flex items-center gap-2">
            <Select value={selectedCountry} onValueChange={onCountryChange}>
              <SelectTrigger className="w-[200px] border-gray-300 focus:border-primary">
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  <SelectValue placeholder="Select country">
                    {getCountryDisplay(selectedCountry)}
                  </SelectValue>
                </div>
              </SelectTrigger>
              <SelectContent className="bg-white border border-gray-200 shadow-lg max-h-60 overflow-auto">
                {countries.map((country) => (
                  <SelectItem
                    key={country.value}
                    value={country.value}
                    className="bg-white hover:bg-gray-100 focus:bg-gray-100 cursor-pointer"
                  >
                    {country.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Date filters */}
          <div className="flex items-center gap-2">
            <Popover open={showDateFilter} onOpenChange={setShowDateFilter}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={`flex items-center gap-2 ${(fromDate || toDate) ? 'bg-primary/10 border-primary/20 text-primary' : ''}`}
                >
                  <Calendar className="h-4 w-4" />
                  {fromDate || toDate ? (
                    <span>
                      {fromDate ? format(fromDate, "MMM d, yyyy") : "Any"} - {toDate ? format(toDate, "MMM d, yyyy") : "Any"}
                    </span>
                  ) : (
                    <span>Date Range</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 bg-white border border-gray-200 shadow-lg" align="end">
                <div className="flex flex-col sm:flex-row p-2 gap-2 bg-white">
                  <div className="space-y-2">
                    <div className="font-medium text-sm">From</div>
                    <CalendarComponent
                      mode="single"
                      selected={fromDate}
                      onSelect={(date) => handleDateChange('from', date)}
                      disabled={(date) => date > new Date()}
                      initialFocus
                      className="bg-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="font-medium text-sm">To</div>
                    <CalendarComponent
                      mode="single"
                      selected={toDate}
                      onSelect={(date) => handleDateChange('to', date)}
                      disabled={(date) => (fromDate && date < fromDate) || date > new Date()}
                      initialFocus
                      className="bg-white"
                    />
                  </div>
                </div>
                <div className="border-t p-2 flex justify-between bg-white">
                  <Button variant="outline" size="sm" onClick={clearDates} disabled={!fromDate && !toDate}>
                    Clear
                  </Button>
                  <Button size="sm" onClick={() => setShowDateFilter(false)}>
                    Apply
                  </Button>
                </div>
              </PopoverContent>
            </Popover>

            {(fromDate || toDate) && (
              <Button variant="ghost" size="icon" onClick={clearDates} title="Clear dates">
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
