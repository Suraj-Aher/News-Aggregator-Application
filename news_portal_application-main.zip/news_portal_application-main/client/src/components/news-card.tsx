import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowRight, User } from "lucide-react";
import { NewsArticle } from "@/lib/api";
import { getCategoryColor, formatDate } from "@/lib/mock-data";

interface NewsCardProps {
  article: NewsArticle;
}

export function NewsCard({ article }: NewsCardProps) {
  const categoryColor = getCategoryColor(article.categoryName || 'Business');

  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <img
        src={article.image || "/placeholder.jpg"}
        alt={article.title}
        className="w-full h-48 object-cover"
      />
      
      <CardContent className="p-6">
        <div className="flex items-center mb-2">
          <Badge
            variant="secondary"
            className={`bg-${categoryColor}-100 text-${categoryColor}-800 text-xs font-medium`}
          >
            {(article.categoryName || 'Business').charAt(0).toUpperCase() + (article.categoryName || 'Business').slice(1)}
          </Badge>
          <span className="ml-2 text-sm text-gray-500">
            {article.source || 'Unknown Source'}
          </span>
        </div>
        
        <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">
          {article.title}
        </h3>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-3">
          {article.description || article.content?.substring(0, 150) + '...'}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="flex-shrink-0">
              <div className="h-8 w-8 rounded-full bg-gray-300 flex items-center justify-center">
                <User className="w-4 h-4 text-gray-600" />
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900">{article.author || 'Unknown Author'}</p>
              <p className="text-xs text-gray-500">{formatDate(article.publishedAt)}</p>
            </div>
          </div>
          
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-primary hover:text-primary/80"
            onClick={() => window.open(article.url, '_blank')}
          >
            Read More <ArrowRight className="ml-1 w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
