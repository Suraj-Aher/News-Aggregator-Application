import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { AuthUser, AuthResponse } from "./api";
import { apiClient, tokenStorage } from "./apiClient";

interface AuthContextType {
  user: AuthUser | null;
  login: (credentials: { email: string; password: string }) => Promise<void>;
  register: (userData: { username: string; email: string; password: string; firstName?: string; lastName?: string }) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored token and validate it
    const initializeAuth = async () => {
      const token = tokenStorage.get();
      
      if (token) {
        try {
          // Validate token with backend
          await apiClient.validateToken();
          // Get current user data
          const userData = await apiClient.getCurrentUser();
          setUser(userData);
          localStorage.setItem("user", JSON.stringify(userData));
        } catch (error) {
          // Token is invalid, clean up
          console.error("Token validation failed:", error);
          tokenStorage.remove();
          localStorage.removeItem("user");
          setUser(null);
        }
      }
      
      setIsLoading(false);
    };

    initializeAuth();
  }, []);

  const login = async (credentials: { email: string; password: string }) => {
    try {
      setIsLoading(true);
      const authResponse: AuthResponse = await apiClient.login(credentials);
      
      // Get full user data
      const userData = await apiClient.getCurrentUser();
      setUser(userData);
      localStorage.setItem("user", JSON.stringify(userData));
    } catch (error) {
      console.error("Login failed:", error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: { username: string; email: string; password: string; firstName?: string; lastName?: string }) => {
    try {
      setIsLoading(true);
      const authResponse: AuthResponse = await apiClient.register(userData);
      
      // Get full user data
      const userDetails = await apiClient.getCurrentUser();
      setUser(userDetails);
      localStorage.setItem("user", JSON.stringify(userDetails));
    } catch (error) {
      console.error("Registration failed:", error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    apiClient.logout();
    setUser(null);
  };

  const isAuthenticated = !!user && !!tokenStorage.get();

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isAuthenticated, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
