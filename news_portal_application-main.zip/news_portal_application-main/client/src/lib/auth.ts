export interface AuthUser {
  id: string;
  username: string;
  email: string;
  role: string;
  name: string;
}

export interface AuthContextType {
  user: AuthUser | null;
  login: (user: AuthUser) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

// Storage utilities for auth state persistence
export const getStoredUser = (): AuthUser | null => {
  try {
    const storedUser = localStorage.getItem("user");
    return storedUser ? JSON.parse(storedUser) : null;
  } catch (error) {
    console.error("Failed to parse stored user:", error);
    localStorage.removeItem("user");
    return null;
  }
};

export const storeUser = (user: AuthUser): void => {
  localStorage.setItem("user", JSON.stringify(user));
};

export const removeStoredUser = (): void => {
  localStorage.removeItem("user");
};

// Auth validation utilities
export const isValidUser = (user: any): user is AuthUser => {
  return (
    user &&
    typeof user.id === "string" &&
    typeof user.username === "string" &&
    typeof user.email === "string" &&
    typeof user.role === "string" &&
    typeof user.name === "string"
  );
};

export const isAdmin = (user: AuthUser | null): boolean => {
  return user?.role === "admin";
};

export const canAccessAdminDashboard = (user: AuthUser | null): boolean => {
  return isAdmin(user);
};

// Session management
export const clearSession = (): void => {
  removeStoredUser();
  // Clear any other session-related data if needed
};

export const initializeSession = (): AuthUser | null => {
  const storedUser = getStoredUser();
  return isValidUser(storedUser) ? storedUser : null;
};
