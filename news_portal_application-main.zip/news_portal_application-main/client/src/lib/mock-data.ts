// Dynamic category loading - categories now come from API
// This file only contains utility functions, no hardcoded data

export const getCategoryColor = (category: string): string => {
  const colors: Record<string, string> = {
    Business: "blue",
    Entertainment: "purple", 
    Health: "green",
    Politics: "red",
    Science: "cyan",
    Sports: "orange",
    Technology: "indigo",
    General: "gray",
  };
  return colors[category] || "gray";
};

export const formatDate = (dateString: string | Date): string => {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};
