import { useEffect } from 'react';
import { useLocation as wouterUseLocation } from 'wouter';

// A hook to scroll to top when route changes
export const useScrollToTop = () => {
  const [location] = wouterUseLocation();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);
};

// Export the original wouter hook directly
export { wouterUseLocation as useLocation };
