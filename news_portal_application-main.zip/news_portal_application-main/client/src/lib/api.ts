// API Configuration for .NET Core Backend
export const API_BASE_URL = 'http://localhost:5000/api';

// API Endpoints
export const API_ENDPOINTS = {
  // Auth endpoints
  LOGIN: `${API_BASE_URL}/auth/login`,
  REGISTER: `${API_BASE_URL}/auth/register`,
  ME: `${API_BASE_URL}/auth/me`,
  VALIDATE: `${API_BASE_URL}/auth/validate`,
  
  // News endpoints
  NEWS: `${API_BASE_URL}/news`,
  NEWS_SEARCH: `${API_BASE_URL}/news/search`,
  NEWS_CATEGORIES: `${API_BASE_URL}/news/categories`,
  NEWS_SYNC: `${API_BASE_URL}/news/sync`,
  NEWS_HEALTH: `${API_BASE_URL}/news/health`,
  NEWS_DASHBOARD_STATS: `${API_BASE_URL}/news/dashboard-stats`,
  
  // User management endpoints
  USERS: `${API_BASE_URL}/users`,
  USER_STATS: `${API_BASE_URL}/users/stats`,
  
  // Category management endpoints
  CATEGORIES: `${API_BASE_URL}/categories`,
} as const;

// Types for .NET Core API responses
export interface NewsArticle {
  id: number;
  title: string;
  description?: string;
  content?: string;
  url: string;
  image?: string;
  publishedAt: string;
  source?: string;
  author?: string;
  categoryId?: number;
  categoryName?: string;
  language?: string;
  country?: string;
}

export interface NewsResponse {
  articles: NewsArticle[];
  totalCount: number;
  page: number;
  pageSize: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

export interface AuthUser {
  id: number;
  username: string;
  email: string;
  firstName?: string;
  lastName?: string;
  role: string;
  createdAt: string;
  isActive: boolean;
}

export interface AuthResponse {
  token: string;
  username: string;
  email: string;
  role: string;
  expiresAt: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
  firstName?: string;
  lastName?: string;
}

export interface NewsFilter {
  categoryId?: number;
  categoryName?: string;
  language?: string;
  country?: string;
  query?: string;
  fromDate?: string;
  toDate?: string;
  page?: number;
  pageSize?: number;
}

export interface DashboardStats {
  totalArticles: number;
  totalCategories: number;
  articlesToday: number;
  articlesThisWeek: number;
  categoryStats: CategoryStat[];
  recentArticles: NewsArticle[];
}

export interface CategoryStat {
  categoryId?: number;
  categoryName?: string;
  count: number;
}

export interface User {
  id: number;
  username: string;
  email: string;
  firstName?: string;
  lastName?: string;
  role: string;
  createdAt: string;
  isActive: boolean;
}

export interface UpdateUser {
  firstName?: string;
  lastName?: string;
  role?: string;
}

export interface UserStats {
  totalUsers: number;
  adminUsers: number;
  regularUsers: number;
  usersToday: number;
  usersThisWeek: number;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
  color?: string;
  articleCount: number;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
}

export interface CreateCategory {
  name: string;
  description?: string;
  icon?: string;
  color?: string;
}

export interface UpdateCategory {
  name: string;
  description?: string;
  icon?: string;
  color?: string;
  isActive?: boolean;
}
