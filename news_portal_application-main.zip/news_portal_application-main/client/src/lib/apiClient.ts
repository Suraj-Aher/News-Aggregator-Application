import { 
  API_ENDPOINTS, 
  AuthResponse, 
  AuthUser, 
  LoginRequest, 
  RegisterRequest, 
  NewsResponse, 
  NewsFilter,
  NewsArticle,
  DashboardStats,
  User,
  UpdateUser,
  UserStats,
  Category,
  CreateCategory,
  UpdateCategory
} from './api';

// Token management
const TOKEN_KEY = 'auth_token';

export const tokenStorage = {
  get: (): string | null => localStorage.getItem(TOKEN_KEY),
  set: (token: string): void => localStorage.setItem(TOKEN_KEY, token),
  remove: (): void => localStorage.removeItem(TOKEN_KEY),
};

// HTTP Client with JWT support
class ApiClient {
  private async request<T>(
    endpoint: string, 
    options: RequestInit = {}
  ): Promise<T> {
    const token = tokenStorage.get();
    
    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...options.headers,
      },
      ...options,
    };

    try {
      const response = await fetch(endpoint, config);
      
      if (!response.ok) {
        if (response.status === 401) {
          // Token expired or invalid
          tokenStorage.remove();
          localStorage.removeItem('user');
          throw new Error('Authentication required');
        }
        
        const errorData = await response.json().catch(() => ({ message: response.statusText }));
        throw new Error(errorData.message || `HTTP ${response.status}`);
      }

      // Handle empty responses
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        return await response.json();
      }
      
      return {} as T;
    } catch (error) {
      console.error('API Request failed:', error);
      throw error;
    }
  }

  // Auth methods
  async login(credentials: LoginRequest): Promise<AuthResponse> {
    const response = await this.request<AuthResponse>(API_ENDPOINTS.LOGIN, {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
    
    // Store token
    tokenStorage.set(response.token);
    
    return response;
  }

  async register(userData: RegisterRequest): Promise<AuthResponse> {
    const response = await this.request<AuthResponse>(API_ENDPOINTS.REGISTER, {
      method: 'POST',
      body: JSON.stringify(userData),
    });
    
    // Store token
    tokenStorage.set(response.token);
    
    return response;
  }

  async getCurrentUser(): Promise<AuthUser> {
    return this.request<AuthUser>(API_ENDPOINTS.ME);
  }

  async validateToken(): Promise<{ isValid: boolean }> {
    return this.request<{ isValid: boolean }>(API_ENDPOINTS.VALIDATE);
  }

  // News methods
  async getNews(filters: NewsFilter = {}): Promise<NewsResponse> {
    const params = new URLSearchParams();
    
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        params.append(key, String(value));
      }
    });

    const url = `${API_ENDPOINTS.NEWS}${params.toString() ? `?${params.toString()}` : ''}`;
    return this.request<NewsResponse>(url);
  }

  async getNewsById(id: number): Promise<NewsArticle> {
    return this.request<NewsArticle>(`${API_ENDPOINTS.NEWS}/${id}`);
  }

  async searchNews(query: string, page = 1, pageSize = 10): Promise<NewsResponse> {
    const params = new URLSearchParams({
      q: query,
      page: String(page),
      pageSize: String(pageSize),
    });

    return this.request<NewsResponse>(`${API_ENDPOINTS.NEWS_SEARCH}?${params.toString()}`);
  }

  async getCategories(): Promise<string[]> {
    return this.request<string[]>(API_ENDPOINTS.NEWS_CATEGORIES);
  }

  async syncNews(category?: string): Promise<{ message: string }> {
    const params = category ? `?category=${encodeURIComponent(category)}` : '';
    return this.request<{ message: string }>(`${API_ENDPOINTS.NEWS_SYNC}${params}`, {
      method: 'POST',
    });
  }

  async healthCheck(): Promise<{ status: string; timestamp: string; version: string }> {
    return this.request<{ status: string; timestamp: string; version: string }>(API_ENDPOINTS.NEWS_HEALTH);
  }

  async getDashboardStats(): Promise<DashboardStats> {
    return this.request<DashboardStats>(API_ENDPOINTS.NEWS_DASHBOARD_STATS);
  }

  // User management methods
  async getUsers(): Promise<User[]> {
    return this.request<User[]>(API_ENDPOINTS.USERS);
  }

  async getUserById(id: number): Promise<User> {
    return this.request<User>(`${API_ENDPOINTS.USERS}/${id}`);
  }

  async updateUser(id: number, userData: UpdateUser): Promise<User> {
    return this.request<User>(`${API_ENDPOINTS.USERS}/${id}`, {
      method: 'PUT',
      body: JSON.stringify(userData),
    });
  }

  async deactivateUser(id: number): Promise<{ message: string }> {
    return this.request<{ message: string }>(`${API_ENDPOINTS.USERS}/${id}`, {
      method: 'DELETE',
    });
  }

  async getUserStats(): Promise<UserStats> {
    return this.request<UserStats>(API_ENDPOINTS.USER_STATS);
  }

  // Category management methods
  async getCategoriesWithStats(): Promise<Category[]> {
    return this.request<Category[]>(API_ENDPOINTS.CATEGORIES);
  }

  async createCategory(categoryData: CreateCategory): Promise<Category> {
    return this.request<Category>(API_ENDPOINTS.CATEGORIES, {
      method: 'POST',
      body: JSON.stringify(categoryData),
    });
  }

  async updateCategory(id: number, categoryData: UpdateCategory): Promise<Category> {
    return this.request<Category>(`${API_ENDPOINTS.CATEGORIES}/${id}`, {
      method: 'PUT',
      body: JSON.stringify(categoryData),
    });
  }

  async deleteCategory(id: number): Promise<{ message: string }> {
    return this.request<{ message: string }>(`${API_ENDPOINTS.CATEGORIES}/${id}`, {
      method: 'DELETE',
    });
  }

  // Logout (client-side only)
  logout(): void {
    tokenStorage.remove();
    localStorage.removeItem('user');
  }
}

export const apiClient = new ApiClient();
