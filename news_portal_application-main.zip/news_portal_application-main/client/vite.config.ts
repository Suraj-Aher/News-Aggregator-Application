import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'
import { fileURLToPath } from 'url'
import viteSpaFallback from './vite-spa-fallback'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

export default defineConfig({
  plugins: [
    react(),
    viteSpaFallback()
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
      },
    },
    port: 5173, // Set specific port
    strictPort: true, // Fail if port is already in use
  },
  // This ensures that the application handles client-side routing correctly
  base: '/',
  // Configure Vite dev server to handle SPA routing
  preview: {
    port: 5173,
  },
})
