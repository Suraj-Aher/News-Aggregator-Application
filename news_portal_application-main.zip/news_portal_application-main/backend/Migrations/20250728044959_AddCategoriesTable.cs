﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using MySql.EntityFrameworkCore.Metadata;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace NewsPortal.API.Migrations
{
    /// <inheritdoc />
    public partial class AddCategoriesTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("MySQL:Charset", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySQL:ValueGenerationStrategy", MySQLValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false),
                    Slug = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false),
                    Description = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: true),
                    Icon = table.Column<string>(type: "varchar(10)", maxLength: 10, nullable: true),
                    Color = table.Column<string>(type: "varchar(20)", maxLength: 20, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime(6)", nullable: false, defaultValueSql: "CURRENT_TIMESTAMP"),
                    UpdatedAt = table.Column<DateTime>(type: "datetime(6)", nullable: false),
                    IsActive = table.Column<bool>(type: "tinyint(1)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.Id);
                })
                .Annotation("MySQL:Charset", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySQL:ValueGenerationStrategy", MySQLValueGenerationStrategy.IdentityColumn),
                    Username = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "varchar(255)", maxLength: 255, nullable: false),
                    PasswordHash = table.Column<string>(type: "longtext", nullable: false),
                    FirstName = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: true),
                    LastName = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime(6)", nullable: false, defaultValueSql: "CURRENT_TIMESTAMP"),
                    UpdatedAt = table.Column<DateTime>(type: "datetime(6)", nullable: true),
                    IsActive = table.Column<bool>(type: "tinyint(1)", nullable: false),
                    Role = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                })
                .Annotation("MySQL:Charset", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "NewsArticles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySQL:ValueGenerationStrategy", MySQLValueGenerationStrategy.IdentityColumn),
                    Title = table.Column<string>(type: "varchar(500)", maxLength: 500, nullable: false),
                    Description = table.Column<string>(type: "TEXT", nullable: true),
                    Content = table.Column<string>(type: "LONGTEXT", nullable: true),
                    Url = table.Column<string>(type: "varchar(255)", nullable: false),
                    Image = table.Column<string>(type: "longtext", nullable: true),
                    PublishedAt = table.Column<DateTime>(type: "datetime(6)", nullable: false),
                    Source = table.Column<string>(type: "varchar(255)", maxLength: 255, nullable: true),
                    Author = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: true),
                    CategoryId = table.Column<int>(type: "int", nullable: false),
                    Category = table.Column<string>(type: "varchar(50)", maxLength: 50, nullable: true),
                    Language = table.Column<string>(type: "varchar(10)", maxLength: 10, nullable: true),
                    Country = table.Column<string>(type: "varchar(10)", maxLength: 10, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime(6)", nullable: false, defaultValueSql: "CURRENT_TIMESTAMP"),
                    UpdatedAt = table.Column<DateTime>(type: "datetime(6)", nullable: true),
                    IsActive = table.Column<bool>(type: "tinyint(1)", nullable: false),
                    ExternalId = table.Column<string>(type: "varchar(255)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_NewsArticles", x => x.Id);
                    table.ForeignKey(
                        name: "FK_NewsArticles_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                })
                .Annotation("MySQL:Charset", "utf8mb4");

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "Color", "CreatedAt", "Description", "Icon", "IsActive", "Name", "Slug", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, "gray", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9930), "General news and updates", "📰", true, "General", "general", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9920) },
                    { 2, "blue", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9930), "Technology and innovation news", "💻", true, "Technology", "technology", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9930) },
                    { 3, "green", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9930), "Business and finance news", "💼", true, "Business", "business", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9930) },
                    { 4, "orange", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9930), "Sports news and updates", "⚽", true, "Sports", "sports", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9930) },
                    { 5, "red", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9940), "Health and medical news", "🏥", true, "Health", "health", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9930) },
                    { 6, "purple", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9940), "Science and research news", "🔬", true, "Science", "science", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9940) },
                    { 7, "pink", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9940), "Entertainment and celebrity news", "🎬", true, "Entertainment", "entertainment", new DateTime(2025, 7, 28, 4, 49, 59, 263, DateTimeKind.Utc).AddTicks(9940) }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "CreatedAt", "Email", "FirstName", "IsActive", "LastName", "PasswordHash", "Role", "UpdatedAt", "Username" },
                values: new object[] { 1, new DateTime(2025, 7, 28, 4, 49, 59, 404, DateTimeKind.Utc).AddTicks(8260), "admin@newsportal.com", "System", true, "Administrator", "$2a$11$B1w9L2Dd0511SEe3XR3Qxe4tVIJ5ELxavCC.sdrIErMwPmPq6oYKa", "Admin", null, "admin" });

            migrationBuilder.CreateIndex(
                name: "IX_Categories_Name",
                table: "Categories",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Categories_Slug",
                table: "Categories",
                column: "Slug",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_NewsArticles_Category",
                table: "NewsArticles",
                column: "Category");

            migrationBuilder.CreateIndex(
                name: "IX_NewsArticles_CategoryId",
                table: "NewsArticles",
                column: "CategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_NewsArticles_ExternalId",
                table: "NewsArticles",
                column: "ExternalId");

            migrationBuilder.CreateIndex(
                name: "IX_NewsArticles_PublishedAt",
                table: "NewsArticles",
                column: "PublishedAt");

            migrationBuilder.CreateIndex(
                name: "IX_NewsArticles_Url",
                table: "NewsArticles",
                column: "Url",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Users_Email",
                table: "Users",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Users_Username",
                table: "Users",
                column: "Username",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "NewsArticles");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Categories");
        }
    }
}
