﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NewsPortal.API.Migrations
{
    /// <inheritdoc />
    public partial class AddCategoryIdColumn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(450), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(450) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(450), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(450) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(450), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(450) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 7,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460) });

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 52, 71, DateTimeKind.Utc).AddTicks(7820), "$2a$11$5.81a74EB63ykLSzPywCpONi7U5XNMbs/xNtgBSY2UR2i9mgbciiO" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3350), new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3340) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3350), new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3350) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3350), new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3350) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3360), new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3350) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3360), new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3360) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3360), new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3360) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 7,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3360), new DateTime(2025, 7, 28, 8, 14, 38, 677, DateTimeKind.Utc).AddTicks(3360) });

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 14, 38, 817, DateTimeKind.Utc).AddTicks(9650), "$2a$11$mXQIZM7rihAjYdZlqWT9KuVWJyJmMb5H1yl57m.Nc5kryAV203F3a" });
        }
    }
}
