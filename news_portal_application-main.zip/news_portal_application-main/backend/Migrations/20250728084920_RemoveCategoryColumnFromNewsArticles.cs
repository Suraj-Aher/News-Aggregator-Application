﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NewsPortal.API.Migrations
{
    /// <inheritdoc />
    public partial class RemoveCategoryColumnFromNewsArticles : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_NewsArticles_Category",
                table: "NewsArticles");

            migrationBuilder.DropColumn(
                name: "Category",
                table: "NewsArticles");

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(620), new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(610) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(620), new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(620) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(620), new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(620) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(620), new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(620) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(620), new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(620) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(630), new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(620) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 7,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(630), new DateTime(2025, 7, 28, 8, 49, 20, 233, DateTimeKind.Utc).AddTicks(630) });

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 49, 20, 373, DateTimeKind.Utc).AddTicks(6110), "$2a$11$w44nf3XhtxXt8J9AMy1GCO6vRkTabNdFsJTG.4GAqFm3gzpaYPjTO" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Category",
                table: "NewsArticles",
                type: "varchar(50)",
                maxLength: 50,
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(450), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(450) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(450), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(450) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(450), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(450) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460) });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 7,
                columns: new[] { "CreatedAt", "UpdatedAt" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460), new DateTime(2025, 7, 28, 8, 20, 51, 930, DateTimeKind.Utc).AddTicks(460) });

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "CreatedAt", "PasswordHash" },
                values: new object[] { new DateTime(2025, 7, 28, 8, 20, 52, 71, DateTimeKind.Utc).AddTicks(7820), "$2a$11$5.81a74EB63ykLSzPywCpONi7U5XNMbs/xNtgBSY2UR2i9mgbciiO" });

            migrationBuilder.CreateIndex(
                name: "IX_NewsArticles_Category",
                table: "NewsArticles",
                column: "Category");
        }
    }
}
