using Microsoft.EntityFrameworkCore;
using NewsPortal.API.Models;

namespace NewsPortal.API.Data
{
    public class NewsPortalDbContext : DbContext
    {
        public NewsPortalDbContext(DbContextOptions<NewsPortalDbContext> options) : base(options)
        {
        }
        
        public DbSet<User> Users { get; set; }
        public DbSet<NewsArticle> NewsArticles { get; set; }
        public DbSet<Category> Categories { get; set; }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            
            // Configure User entity
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasIndex(u => u.Email).IsUnique();
                entity.HasIndex(u => u.Username).IsUnique();
                
                entity.Property(u => u.CreatedAt)
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");
            });
            
            // Configure NewsArticle entity
            modelBuilder.Entity<NewsArticle>(entity =>
            {
                entity.HasIndex(n => n.Url).IsUnique();
                entity.HasIndex(n => n.CategoryId);
                entity.HasIndex(n => n.PublishedAt);
                entity.HasIndex(n => n.ExternalId);
                
                entity.Property(n => n.CreatedAt)
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");
                    
                // Configure relationship with Category
                entity.HasOne(n => n.CategoryNavigation)
                    .WithMany(c => c.Articles)
                    .HasForeignKey(n => n.CategoryId)
                    .OnDelete(DeleteBehavior.Restrict);
            });
            
            // Configure Category entity
            modelBuilder.Entity<Category>(entity =>
            {
                entity.HasIndex(c => c.Name).IsUnique();
                entity.HasIndex(c => c.Slug).IsUnique();
                
                entity.Property(c => c.CreatedAt)
                    .HasDefaultValueSql("CURRENT_TIMESTAMP");
            });
            
            // Seed default categories
            modelBuilder.Entity<Category>().HasData(
                new Category { Id = 1, Name = "General", Slug = "general", Description = "General news and updates", Icon = "📰", Color = "gray", CreatedAt = DateTime.UtcNow },
                new Category { Id = 2, Name = "Technology", Slug = "technology", Description = "Technology and innovation news", Icon = "💻", Color = "blue", CreatedAt = DateTime.UtcNow },
                new Category { Id = 3, Name = "Business", Slug = "business", Description = "Business and finance news", Icon = "💼", Color = "green", CreatedAt = DateTime.UtcNow },
                new Category { Id = 4, Name = "Sports", Slug = "sports", Description = "Sports news and updates", Icon = "⚽", Color = "orange", CreatedAt = DateTime.UtcNow },
                new Category { Id = 5, Name = "Health", Slug = "health", Description = "Health and medical news", Icon = "🏥", Color = "red", CreatedAt = DateTime.UtcNow },
                new Category { Id = 6, Name = "Science", Slug = "science", Description = "Science and research news", Icon = "🔬", Color = "purple", CreatedAt = DateTime.UtcNow },
                new Category { Id = 7, Name = "Entertainment", Slug = "entertainment", Description = "Entertainment and celebrity news", Icon = "🎬", Color = "pink", CreatedAt = DateTime.UtcNow }
            );
            
            // Seed default user (Admin)
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    Username = "admin",
                    Email = "admin@newsportal.com",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("admin123"),
                    FirstName = "System",
                    LastName = "Administrator",
                    Role = "Admin",
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                }
            );
        }
    }
}
