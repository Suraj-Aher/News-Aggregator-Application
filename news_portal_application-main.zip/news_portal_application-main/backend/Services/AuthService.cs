using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using NewsPortal.API.Data;
using NewsPortal.API.DTOs;
using NewsPortal.API.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace NewsPortal.API.Services
{
    public class AuthService : IAuthService
    {
        private readonly NewsPortalDbContext _context;
        private readonly IConfiguration _configuration;
        
        public AuthService(NewsPortalDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        
        public async Task<AuthResponseDto?> LoginAsync(LoginDto loginDto)
        {
            try
            {
                var user = await GetUserByEmailAsync(loginDto.Email);
                
                if (user == null || !user.IsActive)
                {
                    return null;
                }
                
                if (!VerifyPassword(loginDto.Password, user.PasswordHash))
                {
                    return null;
                }
                
                var token = GenerateJwtToken(user);
                var tokenLifetime = int.Parse(_configuration["JWT:TokenLifetime"] ?? "60");
                
                return new AuthResponseDto
                {
                    Token = token,
                    Username = user.Username,
                    Email = user.Email,
                    Role = user.Role,
                    ExpiresAt = DateTime.UtcNow.AddMinutes(tokenLifetime)
                };
            }
            catch (Exception)
            {
                return null;
            }
        }
        
        public async Task<AuthResponseDto?> RegisterAsync(RegisterDto registerDto)
        {
            try
            {
                // Check if user already exists
                var existingUser = await GetUserByEmailAsync(registerDto.Email);
                if (existingUser != null)
                {
                    return null;
                }
                
                // Check if username already exists
                var existingUsername = await _context.Users
                    .FirstOrDefaultAsync(u => u.Username == registerDto.Username);
                if (existingUsername != null)
                {
                    return null;
                }
                
                var user = new User
                {
                    Username = registerDto.Username,
                    Email = registerDto.Email,
                    PasswordHash = HashPassword(registerDto.Password),
                    FirstName = registerDto.FirstName,
                    LastName = registerDto.LastName,
                    Role = "User",
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                };
                
                _context.Users.Add(user);
                await _context.SaveChangesAsync();
                
                var token = GenerateJwtToken(user);
                var tokenLifetime = int.Parse(_configuration["JWT:TokenLifetime"] ?? "60");
                
                return new AuthResponseDto
                {
                    Token = token,
                    Username = user.Username,
                    Email = user.Email,
                    Role = user.Role,
                    ExpiresAt = DateTime.UtcNow.AddMinutes(tokenLifetime)
                };
            }
            catch (Exception)
            {
                return null;
            }
        }
        
        public async Task<User?> GetUserByEmailAsync(string email)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.Email == email && u.IsActive);
        }
        
        public async Task<User?> GetUserByIdAsync(int id)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.Id == id && u.IsActive);
        }
        
        public string GenerateJwtToken(User user)
        {
            var key = Encoding.ASCII.GetBytes(_configuration["JWT:Key"]);
            var tokenLifetime = int.Parse(_configuration["JWT:TokenLifetime"] ?? "60");
            
            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new(ClaimTypes.Name, user.Username),
                new(ClaimTypes.Email, user.Email),
                new(ClaimTypes.Role, user.Role),
                new("userId", user.Id.ToString()),
                new("username", user.Username)
            };
            
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.UtcNow.AddMinutes(tokenLifetime),
                Issuer = _configuration["JWT:Issuer"],
                Audience = _configuration["JWT:Audience"],
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature)
            };
            
            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            
            return tokenHandler.WriteToken(token);
        }
        
        public bool VerifyPassword(string password, string hashedPassword)
        {
            return BCrypt.Net.BCrypt.Verify(password, hashedPassword);
        }
        
        public string HashPassword(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }
    }
}
