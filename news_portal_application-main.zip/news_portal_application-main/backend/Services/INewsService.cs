using NewsPortal.API.DTOs;
using NewsPortal.API.Models;

namespace NewsPortal.API.Services
{
    public interface INewsService
    {
        Task<NewsResponseDto> GetNewsAsync(NewsFilterDto filter);
        Task<NewsArticleDto?> GetNewsByIdAsync(int id);
        Task<bool> SyncNewsFromExternalApiAsync(string? category = null);
        Task<List<string>> GetAvailableCategoriesAsync();
        Task<NewsResponseDto> SearchNewsAsync(string query, int page = 1, int pageSize = 10);
        Task<DashboardStatsDto> GetDashboardStatsAsync();
        Task<bool> SeedIndianNewsAsync();
    }
}
