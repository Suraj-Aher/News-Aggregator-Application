using Microsoft.EntityFrameworkCore;
using NewsPortal.API.Data;
using NewsPortal.API.DTOs;
using NewsPortal.API.Models;
using Newtonsoft.Json;
using System.Text;

namespace NewsPortal.API.Services
{
    public class NewsService : INewsService
    {
        private readonly NewsPortalDbContext _context;
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly ILogger<NewsService> _logger;
        
        public NewsService(
            NewsPortalDbContext context, 
            HttpClient httpClient, 
            IConfiguration configuration,
            ILogger<NewsService> logger)
        {
            _context = context;
            _httpClient = httpClient;
            _configuration = configuration;
            _logger = logger;
        }
        
        public async Task<NewsResponseDto> GetNewsAsync(NewsFilterDto filter)
        {
            var query = _context.NewsArticles
                .Include(n => n.CategoryNavigation)
                .Where(n => n.IsActive);
            
            // Apply filters
            if (filter.CategoryId.HasValue)
            {
                query = query.Where(n => n.CategoryId == filter.CategoryId);
            }
            
            if (!string.IsNullOrEmpty(filter.CategoryName))
            {
                query = query.Where(n => n.CategoryNavigation != null && n.CategoryNavigation.Name == filter.CategoryName);
            }
            
            if (!string.IsNullOrEmpty(filter.Language))
            {
                query = query.Where(n => n.Language == filter.Language);
            }
            
            if (!string.IsNullOrEmpty(filter.Country))
            {
                query = query.Where(n => n.Country == filter.Country);
            }
            
            if (!string.IsNullOrEmpty(filter.Query))
            {
                query = query.Where(n => n.Title.Contains(filter.Query) || 
                                        n.Description.Contains(filter.Query));
            }
            
            if (filter.FromDate.HasValue)
            {
                query = query.Where(n => n.PublishedAt >= filter.FromDate.Value);
            }
            
            if (filter.ToDate.HasValue)
            {
                query = query.Where(n => n.PublishedAt <= filter.ToDate.Value);
            }
            
            // Order by published date (newest first)
            query = query.OrderByDescending(n => n.PublishedAt);
            
            var totalCount = await query.CountAsync();
            
            // Apply pagination
            var articles = await query
                .Skip((filter.Page - 1) * filter.PageSize)
                .Take(filter.PageSize)
                .Select(n => new NewsArticleDto
                {
                    Id = n.Id,
                    Title = n.Title,
                    Description = n.Description,
                    Content = n.Content,
                    Url = n.Url,
                    Image = n.Image,
                    PublishedAt = n.PublishedAt,
                    Source = n.Source,
                    Author = n.Author,
                    CategoryId = n.CategoryId,
                    CategoryName = n.CategoryNavigation != null ? n.CategoryNavigation.Name : null,
                    Language = n.Language,
                    Country = n.Country
                })
                .ToListAsync();
            
            var totalPages = (int)Math.Ceiling((double)totalCount / filter.PageSize);
            
            return new NewsResponseDto
            {
                Articles = articles,
                TotalCount = totalCount,
                Page = filter.Page,
                PageSize = filter.PageSize,
                TotalPages = totalPages,
                HasNextPage = filter.Page < totalPages,
                HasPreviousPage = filter.Page > 1
            };
        }
        
        public async Task<NewsArticleDto?> GetNewsByIdAsync(int id)
        {
            var article = await _context.NewsArticles
                .Include(n => n.CategoryNavigation)
                .Where(n => n.Id == id && n.IsActive)
                .Select(n => new NewsArticleDto
                {
                    Id = n.Id,
                    Title = n.Title,
                    Description = n.Description,
                    Content = n.Content,
                    Url = n.Url,
                    Image = n.Image,
                    PublishedAt = n.PublishedAt,
                    Source = n.Source,
                    Author = n.Author,
                    CategoryId = n.CategoryId,
                    CategoryName = n.CategoryNavigation != null ? n.CategoryNavigation.Name : null,
                    Language = n.Language,
                    Country = n.Country
                })
                .FirstOrDefaultAsync();
                
            return article;
        }
        
        public async Task<bool> SyncNewsFromExternalApiAsync(string? category = null)
        {
            try
            {
                var apiKey = _configuration["NewsAPI:ApiKey"];
                var baseUrl = _configuration["NewsAPI:BaseUrl"];
                
                if (string.IsNullOrEmpty(apiKey) || string.IsNullOrEmpty(baseUrl))
                {
                    _logger.LogError("NewsAPI configuration is missing");
                    return false;
                }
                
                // Use NewsAPI category names that will be mapped to our database categories
                var categories = new[] { "general", "business", "entertainment", "sports", "science", "health", "technology" };
                
                if (!string.IsNullOrEmpty(category))
                {
                    categories = new[] { category };
                }
                
                foreach (var cat in categories)
                {
                    var url = $"{baseUrl}?category={cat}&country=us&pageSize=20&apiKey={apiKey}";
                    
                    try
                    {
                        using var request = new HttpRequestMessage(HttpMethod.Get, url);
                        request.Headers.Add("User-Agent", "NewsPortalApp/1.0");
                        
                        var httpResponse = await _httpClient.SendAsync(request);
                        var response = await httpResponse.Content.ReadAsStringAsync();
                        
                        if (!httpResponse.IsSuccessStatusCode)
                        {
                            _logger.LogError($"NewsAPI returned error {httpResponse.StatusCode}: {response}");
                            throw new HttpRequestException($"Response status code does not indicate success: {httpResponse.StatusCode}");
                        }
                        
                        var newsApiResponse = JsonConvert.DeserializeObject<NewsApiResponse>(response);
                        
                        if (newsApiResponse?.Articles != null && newsApiResponse.Status == "ok")
                        {
                            foreach (var article in newsApiResponse.Articles)
                            {
                                // Check if article already exists
                                var existingArticle = await _context.NewsArticles
                                    .FirstOrDefaultAsync(n => n.Url == article.Url);
                                
                                if (existingArticle == null)
                                {
                                    // Find the category ID based on category name
                                    var categoryId = await GetCategoryIdByNameAsync(cat);
                                    
                                    var newsArticle = new NewsArticle
                                    {
                                        Title = article.Title?.Substring(0, Math.Min(article.Title.Length, 500)) ?? "",
                                        Description = article.Description,
                                        Content = article.Content,
                                        Url = article.Url,
                                        Image = article.UrlToImage,
                                        PublishedAt = article.PublishedAt,
                                        Source = article.Source?.Name,
                                        Author = article.Author,
                                        CategoryId = categoryId,
                                        Language = "en",
                                        Country = "us",
                                        CreatedAt = DateTime.UtcNow,
                                        IsActive = true
                                    };
                                    
                                    _context.NewsArticles.Add(newsArticle);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, $"Error fetching news for category: {cat}");
                        
                        // If API fails, add mock data for demonstration
                        await AddMockNewsForCategory(cat);
                    }
                    
                    // Save changes after each category to avoid duplicate key issues
                    try
                    {
                        await _context.SaveChangesAsync();
                    }
                    catch (DbUpdateException dbEx) when (dbEx.InnerException?.Message?.Contains("Duplicate entry") == true)
                    {
                        _logger.LogWarning($"Duplicate entries found for category {cat}, some articles may have been skipped");
                        // Clear any pending changes that caused the duplicate key error
                        foreach (var entry in _context.ChangeTracker.Entries()
                            .Where(e => e.State == EntityState.Added))
                        {
                            entry.State = EntityState.Detached;
                        }
                    }
                    
                    // Add delay between requests to avoid rate limiting
                    await Task.Delay(1000);
                }
                
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error syncing news from external API");
                return false;
            }
        }
        
        public async Task<List<string>> GetAvailableCategoriesAsync()
        {
            var categories = await _context.Categories
                .Where(c => c.IsActive)
                .Select(c => c.Name)
                .OrderBy(c => c)
                .ToListAsync();
                
            return categories;
        }
        
        public async Task<NewsResponseDto> SearchNewsAsync(string query, int page = 1, int pageSize = 10)
        {
            var filter = new NewsFilterDto
            {
                Query = query,
                Page = page,
                PageSize = pageSize
            };
            
            return await GetNewsAsync(filter);
        }

        public async Task<DashboardStatsDto> GetDashboardStatsAsync()
        {
            var now = DateTime.UtcNow;
            var today = now.Date;
            var weekAgo = today.AddDays(-7);

            var totalArticles = await _context.NewsArticles
                .Where(n => n.IsActive)
                .CountAsync();

            var totalCategories = await _context.Categories
                .Where(c => c.IsActive)
                .CountAsync();

            var articlesToday = await _context.NewsArticles
                .Where(n => n.IsActive && n.PublishedAt.Date == today)
                .CountAsync();

            var articlesThisWeek = await _context.NewsArticles
                .Where(n => n.IsActive && n.PublishedAt.Date >= weekAgo)
                .CountAsync();

            var categoryStats = await _context.NewsArticles
                .Where(n => n.IsActive && n.CategoryId.HasValue)
                .Include(n => n.CategoryNavigation)
                .GroupBy(n => n.CategoryNavigation)
                .Select(g => new CategoryStatsDto
                {
                    CategoryId = g.Key.Id,
                    CategoryName = g.Key.Name,
                    Count = g.Count()
                })
                .OrderByDescending(cs => cs.Count)
                .ToListAsync();

            var recentArticles = await _context.NewsArticles
                .Include(n => n.CategoryNavigation)
                .Where(n => n.IsActive)
                .OrderByDescending(n => n.PublishedAt)
                .Take(5)
                .Select(n => new NewsArticleDto
                {
                    Id = n.Id,
                    Title = n.Title,
                    Description = n.Description,
                    Content = n.Content,
                    Url = n.Url,
                    Image = n.Image,
                    PublishedAt = n.PublishedAt,
                    Source = n.Source,
                    Author = n.Author,
                    CategoryId = n.CategoryId,
                    CategoryName = n.CategoryNavigation != null ? n.CategoryNavigation.Name : null,
                    Language = n.Language,
                    Country = n.Country
                })
                .ToListAsync();

            return new DashboardStatsDto
            {
                TotalArticles = totalArticles,
                TotalCategories = totalCategories,
                ArticlesToday = articlesToday,
                ArticlesThisWeek = articlesThisWeek,
                CategoryStats = categoryStats,
                RecentArticles = recentArticles
            };
        }

        private async Task AddMockNewsForCategory(string category)
        {
            var mockArticles = await GetMockArticlesForCategoryAsync(category);
            
            foreach (var article in mockArticles)
            {
                // Check if article already exists
                var existingArticle = await _context.NewsArticles
                    .FirstOrDefaultAsync(a => a.Url == article.Url && a.IsActive);
                
                if (existingArticle == null)
                {
                    _context.NewsArticles.Add(article);
                }
            }
        }

        private async Task<List<NewsArticle>> GetMockArticlesForCategoryAsync(string category)
        {
            var baseDate = DateTime.UtcNow.AddDays(-1);
            var articles = new List<NewsArticle>();
            var categoryId = await GetCategoryIdByNameAsync(category);

            switch (category.ToLower())
            {
                case "general":
                    articles.AddRange(new[]
                    {
                        new NewsArticle
                        {
                            Title = "Breaking: Major Economic Summit Concludes with Historic Agreement",
                            Description = "World leaders reach consensus on global trade policies that could reshape international commerce for decades to come.",
                            Content = "In a landmark decision that surprised many analysts, the Global Economic Summit has concluded with unprecedented cooperation between major world powers. The agreement addresses key issues including trade tariffs, environmental standards, and digital currency regulations.",
                            Url = $"https://example.com/news/economic-summit-{Guid.NewGuid()}",
                            Image = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=600&h=400&fit=crop",
                            PublishedAt = baseDate.AddHours(-2),
                            Source = "Global News Network",
                            Author = "Sarah Johnson",
                            CategoryId = categoryId,
                            Language = "en",
                            Country = "us",
                            IsActive = true,
                            CreatedAt = DateTime.UtcNow
                        },
                        new NewsArticle
                        {
                            Title = "Climate Scientists Report Breakthrough in Carbon Capture Technology",
                            Description = "Revolutionary new method could remove atmospheric CO2 at unprecedented scale, offering hope in fight against climate change.",
                            Content = "Researchers at leading universities have developed a new carbon capture technology that is both more efficient and cost-effective than previous methods. The breakthrough could significantly impact global efforts to combat climate change.",
                            Url = $"https://example.com/news/carbon-capture-{Guid.NewGuid()}",
                            Image = "https://images.unsplash.com/photo-1569163139394-de4e4ad52f21?w=600&h=400&fit=crop",
                            PublishedAt = baseDate.AddHours(-4),
                            Source = "Science Daily",
                            Author = "Dr. Michael Chen",
                            CategoryId = categoryId,
                            Language = "en",
                            Country = "us",
                            IsActive = true,
                            CreatedAt = DateTime.UtcNow
                        }
                    });
                    break;

                case "technology":
                    articles.AddRange(new[]
                    {
                        new NewsArticle
                        {
                            Title = "AI Revolution: New Neural Network Achieves Human-Level Reasoning",
                            Description = "Latest advancement in artificial intelligence demonstrates unprecedented problem-solving capabilities across multiple domains.",
                            Content = "A breakthrough in artificial intelligence research has produced a neural network that can reason and solve problems at a level comparable to human intelligence. This development marks a significant milestone in AI development.",
                            Url = $"https://example.com/news/ai-breakthrough-{Guid.NewGuid()}",
                            Image = "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=600&h=400&fit=crop",
                            PublishedAt = baseDate.AddHours(-1),
                            Source = "Tech Insider",
                            Author = "Alex Rodriguez",
                            CategoryId = categoryId,
                            Language = "en",
                            Country = "us",
                            IsActive = true,
                            CreatedAt = DateTime.UtcNow
                        },
                        new NewsArticle
                        {
                            Title = "Quantum Computing Milestone: First Commercial Quantum Internet Connection",
                            Description = "Companies successfully establish secure quantum communication channel between major cities, paving way for quantum internet.",
                            Content = "In a historic achievement, researchers have established the first commercial quantum internet connection between two major cities. This quantum communication channel offers unprecedented security and could revolutionize data transmission.",
                            Url = $"https://example.com/news/quantum-internet-{Guid.NewGuid()}",
                            Image = "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=600&h=400&fit=crop",
                            PublishedAt = baseDate.AddHours(-6),
                            Source = "Quantum Weekly",
                            Author = "Dr. Lisa Park",
                            CategoryId = categoryId,
                            Language = "en",
                            Country = "us",
                            IsActive = true,
                            CreatedAt = DateTime.UtcNow
                        }
                    });
                    break;

                case "business":
                    articles.AddRange(new[]
                    {
                        new NewsArticle
                        {
                            Title = "Stock Markets Surge as Tech Giants Report Record Quarterly Earnings",
                            Description = "Major technology companies exceed analysts' expectations, driving significant gains across global stock markets.",
                            Content = "Wall Street and international markets are experiencing significant gains following the release of quarterly earnings reports from major technology companies. The strong performance has exceeded analyst expectations and boosted investor confidence.",
                            Url = $"https://example.com/news/stock-surge-{Guid.NewGuid()}",
                            Image = "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=600&h=400&fit=crop",
                            PublishedAt = baseDate.AddHours(-3),
                            Source = "Financial Times",
                            Author = "Robert Kim",
                            CategoryId = categoryId,
                            Language = "en",
                            Country = "us",
                            IsActive = true,
                            CreatedAt = DateTime.UtcNow
                        }
                    });
                    break;

                case "sports":
                    articles.AddRange(new[]
                    {
                        new NewsArticle
                        {
                            Title = "Championship Victory: Underdog Team Claims Historic Sports Title",
                            Description = "Against all odds, the determined team overcomes seasoned veterans to win their first championship in decades.",
                            Content = "In one of the most surprising upsets in recent sports history, an underdog team has claimed the championship title. Their victory represents years of dedication and strategic improvement.",
                            Url = $"https://example.com/news/championship-{Guid.NewGuid()}",
                            Image = "https://images.unsplash.com/photo-1579952363873-27d3bfad9c0d?w=600&h=400&fit=crop",
                            PublishedAt = baseDate.AddHours(-5),
                            Source = "Sports Central",
                            Author = "Mike Thompson",
                            CategoryId = categoryId,
                            Language = "en",
                            Country = "us",
                            IsActive = true,
                            CreatedAt = DateTime.UtcNow
                        }
                    });
                    break;

                case "entertainment":
                    articles.AddRange(new[]
                    {
                        new NewsArticle
                        {
                            Title = "Hollywood Stars Unite for Major Charity Film Project",
                            Description = "A-list celebrities collaborate on groundbreaking film that will donate all proceeds to global humanitarian causes.",
                            Content = "In an unprecedented move, major Hollywood stars have come together to create a film where all profits will be donated to humanitarian causes worldwide. The project represents a new model for celebrity philanthropy.",
                            Url = $"https://example.com/news/charity-film-{Guid.NewGuid()}",
                            Image = "https://images.unsplash.com/photo-1489599735734-79b4169c2a78?w=600&h=400&fit=crop",
                            PublishedAt = baseDate.AddHours(-4),
                            Source = "Entertainment Weekly",
                            Author = "Jennifer Adams",
                            CategoryId = categoryId,
                            Language = "en",
                            Country = "us",
                            IsActive = true,
                            CreatedAt = DateTime.UtcNow
                        }
                    });
                    break;

                default:
                    // Add a generic article for other categories
                    articles.Add(new NewsArticle
                    {
                        Title = $"Latest Updates in {category.ToUpper()}: Important Developments",
                        Description = $"Stay informed with the latest news and developments in the {category} sector.",
                        Content = $"Recent developments in the {category} sector have shown significant progress. Industry experts continue to monitor trends and provide insights for stakeholders.",
                        Url = $"https://example.com/news/{category}-update-{Guid.NewGuid()}",
                        Image = "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=600&h=400&fit=crop",
                        PublishedAt = baseDate.AddHours(-3),
                        Source = "News Aggregator",
                        Author = "Editorial Team",
                        CategoryId = categoryId,
                        Language = "en",
                        Country = "us",
                        IsActive = true,
                        CreatedAt = DateTime.UtcNow
                    });
                    break;
            }

            return articles;
        }

        private async Task<int?> GetCategoryIdByNameAsync(string categoryName)
        {
            // Create a mapping of NewsAPI category names to our database categories
            var categoryMapping = new Dictionary<string, string>
            {
                ["general"] = "Business",      // Map general to business as fallback
                ["business"] = "Business",
                ["technology"] = "Science",    // Map technology to science since we don't have tech category
                ["entertainment"] = "Entertainment",
                ["sports"] = "Sports",
                ["science"] = "Science",
                ["health"] = "Health"
            };

            var mappedName = categoryMapping.ContainsKey(categoryName.ToLower()) 
                ? categoryMapping[categoryName.ToLower()] 
                : categoryName;

            var category = await _context.Categories
                .Where(c => c.Name.ToLower() == mappedName.ToLower() && c.IsActive)
                .FirstOrDefaultAsync();

            return category?.Id;
        }

        private async Task SaveArticleIfNotExists(NewsApiArticle article, string categoryName, string countryCode)
        {
            var existingArticle = await _context.NewsArticles
                .FirstOrDefaultAsync(n => n.Url == article.Url);
            
            if (existingArticle == null)
            {
                var categoryId = await GetCategoryIdByNameAsync(categoryName);
                
                var newsArticle = new NewsArticle
                {
                    Title = article.Title?.Substring(0, Math.Min(article.Title.Length, 500)) ?? "",
                    Description = article.Description,
                    Content = article.Content,
                    Url = article.Url,
                    Image = article.UrlToImage,
                    PublishedAt = article.PublishedAt,
                    Source = article.Source?.Name,
                    Author = article.Author,
                    CategoryId = categoryId,
                    Language = "en",
                    Country = countryCode,
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                };
                
                _context.NewsArticles.Add(newsArticle);
            }
        }

        private string DetermineCountryFromSource(string? sourceName, string? url)
        {
            if (string.IsNullOrEmpty(sourceName) && string.IsNullOrEmpty(url))
                return "us"; // Default to US
            
            var source = (sourceName ?? "").ToLower();
            var urlStr = (url ?? "").ToLower();
            
            // Indian sources
            if (source.Contains("times of india") || source.Contains("hindu") || source.Contains("ndtv") || 
                source.Contains("india today") || source.Contains("firstpost") || source.Contains("indian express") ||
                urlStr.Contains("timesofindia") || urlStr.Contains("thehindu") || urlStr.Contains("ndtv") ||
                urlStr.Contains("indiatoday") || urlStr.Contains("firstpost") || urlStr.Contains("indianexpress"))
                return "in";
            
            // UK sources
            if (source.Contains("bbc") || source.Contains("guardian") || source.Contains("telegraph") || 
                source.Contains("independent") || source.Contains("sky news") || source.Contains("daily mail") ||
                urlStr.Contains("bbc.co.uk") || urlStr.Contains("guardian.co.uk") || urlStr.Contains("telegraph.co.uk") ||
                urlStr.Contains("independent.co.uk") || urlStr.Contains("skynews.com") || urlStr.Contains("dailymail.co.uk"))
                return "gb";
            
            // Canadian sources
            if (source.Contains("cbc") || source.Contains("globe and mail") || source.Contains("national post") ||
                urlStr.Contains("cbc.ca") || urlStr.Contains("theglobeandmail.com") || urlStr.Contains("nationalpost.com"))
                return "ca";
            
            // Australian sources
            if (source.Contains("abc.net.au") || source.Contains("herald") || source.Contains("australian") ||
                urlStr.Contains("abc.net.au") || urlStr.Contains("smh.com.au") || urlStr.Contains("theaustralian.com.au"))
                return "au";
            
            // Default to US for everything else
            return "us";
        }

        public async Task<bool> SeedIndianNewsAsync()
        {
            try
            {
                var indianArticles = new[]
                {
                    new NewsArticle
                    {
                        Title = "India Launches New Digital Initiative for Rural Healthcare",
                        Description = "The Indian government today announced a comprehensive digital healthcare initiative aimed at improving medical services in rural areas across the country.",
                        Content = "In a landmark announcement today, Prime Minister Modi unveiled a new digital healthcare initiative that will bring telemedicine and digital health records to over 600,000 villages across India. The program, called Digital Bharat Health, aims to bridge the healthcare gap between urban and rural areas by leveraging technology and mobile connectivity.",
                        Url = "https://example-india-news.com/digital-healthcare-initiative",
                        Image = "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800",
                        PublishedAt = DateTime.UtcNow.AddHours(-2),
                        Source = "Times of India",
                        Author = "Rajesh Sharma",
                        CategoryId = 1, // General
                        Language = "en",
                        Country = "in",
                        CreatedAt = DateTime.UtcNow,
                        IsActive = true
                    },
                    new NewsArticle
                    {
                        Title = "India's Space Mission Achieves Historic Milestone",
                        Description = "ISRO successfully completed its latest lunar mission, marking another achievement for India's space program.",
                        Content = "The Indian Space Research Organisation (ISRO) has successfully completed its Chandrayaan-4 mission to the Moon, marking another significant achievement in India's rapidly advancing space program. The mission included successful deployment of advanced scientific instruments on the lunar surface.",
                        Url = "https://example-india-news.com/space-mission-milestone",
                        Image = "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=800",
                        PublishedAt = DateTime.UtcNow.AddHours(-4),
                        Source = "The Hindu",
                        Author = "Dr. Priya Nair",
                        CategoryId = 6, // Science
                        Language = "en",
                        Country = "in",
                        CreatedAt = DateTime.UtcNow,
                        IsActive = true
                    },
                    new NewsArticle
                    {
                        Title = "Indian Cricket Team Wins Historic Test Series",
                        Description = "India secured a decisive victory in the five-match Test series against Australia, winning 3-1 in a thrilling conclusion.",
                        Content = "The Indian cricket team has achieved a remarkable victory in the five-match Test series against Australia, winning 3-1 in what many are calling one of the most exciting series in recent memory. The victory was sealed with an outstanding performance by the Indian bowling attack led by captain Rohit Sharma.",
                        Url = "https://example-india-news.com/cricket-test-series-win",
                        Image = "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=800",
                        PublishedAt = DateTime.UtcNow.AddHours(-6),
                        Source = "Indian Express",
                        Author = "Arjun Kapoor",
                        CategoryId = 4, // Sports
                        Language = "en",
                        Country = "in",
                        CreatedAt = DateTime.UtcNow,
                        IsActive = true
                    },
                    new NewsArticle
                    {
                        Title = "New Tech Hub Announced in Bangalore",
                        Description = "A major technology hub is being established in Bangalore, expected to create over 50,000 new jobs in the next five years.",
                        Content = "The Karnataka government has announced the establishment of a new technology hub in Bangalore that will focus on artificial intelligence, machine learning, and blockchain technologies. The initiative is expected to attract major international tech companies and create over 50,000 high-skilled jobs in the region over the next five years.",
                        Url = "https://example-india-news.com/bangalore-tech-hub",
                        Image = "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800",
                        PublishedAt = DateTime.UtcNow.AddHours(-8),
                        Source = "NDTV",
                        Author = "Sunita Menon",
                        CategoryId = 7, // Technology
                        Language = "en",
                        Country = "in",
                        CreatedAt = DateTime.UtcNow,
                        IsActive = true
                    },
                    new NewsArticle
                    {
                        Title = "India's Economic Growth Surpasses Expectations",
                        Description = "The latest quarterly GDP figures show India's economy growing at 7.2%, exceeding all analyst predictions.",
                        Content = "India's economy has demonstrated remarkable resilience with the latest quarterly GDP figures showing a growth rate of 7.2%, significantly higher than the predicted 6.5%. This growth is attributed to strong domestic consumption, increased manufacturing output, and robust services sector performance.",
                        Url = "https://example-india-news.com/economic-growth",
                        Image = "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800",
                        PublishedAt = DateTime.UtcNow.AddHours(-10),
                        Source = "Economic Times",
                        Author = "Vikram Singh",
                        CategoryId = 2, // Business
                        Language = "en",
                        Country = "in",
                        CreatedAt = DateTime.UtcNow,
                        IsActive = true
                    }
                };

                foreach (var article in indianArticles)
                {
                    var existingArticle = await _context.NewsArticles
                        .FirstOrDefaultAsync(n => n.Url == article.Url);
                    
                    if (existingArticle == null)
                    {
                        _context.NewsArticles.Add(article);
                    }
                }

                var savedCount = await _context.SaveChangesAsync();
                _logger.LogInformation($"Seeded {savedCount} Indian news articles");
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error seeding Indian news articles");
                return false;
            }
        }
    }
}
