using NewsPortal.API.DTOs;
using NewsPortal.API.Models;

namespace NewsPortal.API.Services
{
    public interface IAuthService
    {
        Task<AuthResponseDto?> LoginAsync(LoginDto loginDto);
        Task<AuthResponseDto?> RegisterAsync(RegisterDto registerDto);
        Task<User?> GetUserByEmailAsync(string email);
        Task<User?> GetUserByIdAsync(int id);
        string GenerateJwtToken(User user);
        bool VerifyPassword(string password, string hashedPassword);
        string HashPassword(string password);
    }
}
