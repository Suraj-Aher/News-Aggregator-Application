namespace NewsPortal.API.DTOs
{
    public class NewsArticleDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string? Content { get; set; }
        public string Url { get; set; } = string.Empty;
        public string? Image { get; set; }
        public DateTime PublishedAt { get; set; }
        public string? Source { get; set; }
        public string? Author { get; set; }
        public int? CategoryId { get; set; }
        public string? CategoryName { get; set; }
        public string? Language { get; set; }
        public string? Country { get; set; }
    }
    
    public class NewsFilterDto
    {
        public int? CategoryId { get; set; }
        public string? CategoryName { get; set; }
        public string? Language { get; set; }
        public string? Country { get; set; }
        public string? Query { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }
    
    public class NewsResponseDto
    {
        public List<NewsArticleDto> Articles { get; set; } = new();
        public int TotalCount { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int TotalPages { get; set; }
        public bool HasNextPage { get; set; }
        public bool HasPreviousPage { get; set; }
    }
    
    // DTOs for NewsAPI response
    public class NewsApiResponse
    {
        public string Status { get; set; } = string.Empty;
        public int TotalResults { get; set; }
        public List<NewsApiArticle> Articles { get; set; } = new();
    }
    
    public class NewsApiArticle
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Url { get; set; } = string.Empty;
        public string UrlToImage { get; set; } = string.Empty;
        public DateTime PublishedAt { get; set; }
        public string Content { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
        public NewsApiSource Source { get; set; } = new();
    }
    
    public class NewsApiSource
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
    }

    public class DashboardStatsDto
    {
        public int TotalArticles { get; set; }
        public int TotalCategories { get; set; }
        public int ArticlesToday { get; set; }
        public int ArticlesThisWeek { get; set; }
        public List<CategoryStatsDto> CategoryStats { get; set; } = new();
        public List<NewsArticleDto> RecentArticles { get; set; } = new();
    }

    public class CategoryStatsDto
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public int Count { get; set; }
    }
}
