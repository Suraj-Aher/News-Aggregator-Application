namespace NewsPortal.API.DTOs
{
    public class UpdateUserDto
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Role { get; set; }
    }

    public class UserStatsDto
    {
        public int TotalUsers { get; set; }
        public int AdminUsers { get; set; }
        public int RegularUsers { get; set; }
        public int UsersToday { get; set; }
        public int UsersThisWeek { get; set; }
    }
}
