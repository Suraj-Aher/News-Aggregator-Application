using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NewsPortal.API.Models
{
    public class NewsArticle
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        [StringLength(500)]
        public string Title { get; set; } = string.Empty;
        
        [Column(TypeName = "TEXT")]
        public string? Description { get; set; }
        
        [Column(TypeName = "LONGTEXT")]
        public string? Content { get; set; }
        
        [Required]
        [Url]
        public string Url { get; set; } = string.Empty;
        
        [Url]
        public string? Image { get; set; }
        
        public DateTime PublishedAt { get; set; }
        
        [StringLength(255)]
        public string? Source { get; set; }
        
        [StringLength(100)]
        public string? Author { get; set; }
        
        // Foreign key to Categories table
        public int? CategoryId { get; set; }
        
        [StringLength(10)]
        public string? Language { get; set; }
        
        [StringLength(10)]
        public string? Country { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        
        public DateTime? UpdatedAt { get; set; }
        
        public bool IsActive { get; set; } = true;
        
        // Navigation property
        [ForeignKey("CategoryId")]
        public virtual Category? CategoryNavigation { get; set; }
        
        // External API identifier
        public string? ExternalId { get; set; }
    }
}
