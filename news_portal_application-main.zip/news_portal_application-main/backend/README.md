# News Aggregator Backend API

## Overview
This is the backend API for the News Aggregator application built with ASP.NET Core 8.0, Entity Framework Core, and MySQL.

## Features
- **JWT Authentication**: Secure user registration and login
- **News Management**: Fetch, store, and display news articles
- **External API Integration**: Sync news from GNews API
- **Category Filtering**: Filter news by categories
- **Search Functionality**: Search news articles
- **Swagger Documentation**: Interactive API documentation
- **Role-based Authorization**: Admin and User roles

## Technologies Used
- ASP.NET Core 8.0 Web API
- Entity Framework Core with MySQL
- JWT Bearer Authentication
- BCrypt for password hashing
- Swagger/OpenAPI for documentation
- GNews API for external news data

## Prerequisites
- .NET 8.0 SDK
- MySQL Server 8.0+
- GNews API Key (get from https://gnews.io/)

## Setup Instructions

### 1. Database Setup
1. Install MySQL Server
2. Create a new database named `NewsPortalDB`
3. Update connection string in `appsettings.json`

### 2. Configuration
Update the following in `appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=NewsPortalDB;Uid=your_username;Pwd=your_password;"
  },
  "GNewsAPI": {
    "ApiKey": "your_gnews_api_key_here"
  }
}
```

### 3. Install Dependencies
```bash
dotnet restore
```

### 4. Database Migration
```bash
dotnet ef database update
```

### 5. Run the Application
```bash
dotnet run
```

The API will be available at:
- HTTPS: `https://localhost:7000`
- HTTP: `http://localhost:5000`
- Swagger UI: `https://localhost:7000` (root path)

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `GET /api/auth/me` - Get current user info (requires auth)
- `GET /api/auth/validate` - Validate JWT token (requires auth)

### News
- `GET /api/news` - Get news with filtering and pagination
- `GET /api/news/{id}` - Get specific news article
- `GET /api/news/search` - Search news articles
- `GET /api/news/categories` - Get available categories
- `POST /api/news/sync` - Sync news from external API (Admin only)
- `GET /api/news/health` - Health check

## Default Admin User
- **Email**: admin@newsportal.com
- **Password**: admin123
- **Role**: Admin

## Authentication
The API uses JWT Bearer tokens. Include the token in the Authorization header:
```
Authorization: Bearer your_jwt_token_here
```

## Categories
Supported news categories:
- general
- world
- nation
- business
- technology
- entertainment
- sports
- science
- health

## Error Handling
The API returns appropriate HTTP status codes:
- 200: Success
- 400: Bad Request
- 401: Unauthorized
- 403: Forbidden
- 404: Not Found
- 500: Internal Server Error

## Rate Limiting
The GNews API has rate limits. The sync endpoint includes delays between requests to avoid hitting limits.

## Security Features
- Password hashing using BCrypt
- JWT token-based authentication
- Role-based authorization
- CORS configuration for React frontend
- Input validation and sanitization

## Development Commands

### Entity Framework Commands
```bash
# Add new migration
dotnet ef migrations add MigrationName

# Update database
dotnet ef database update

# Remove last migration
dotnet ef migrations remove
```

### Build and Deployment
```bash
# Build the project
dotnet build

# Publish for production
dotnet publish -c Release
```

## Environment Variables
For production, consider using environment variables:
- `ASPNETCORE_ENVIRONMENT`: Set to "Production"
- `JWT__Key`: JWT signing key
- `ConnectionStrings__DefaultConnection`: Database connection string
- `GNewsAPI__ApiKey`: GNews API key

## Logging
The application uses built-in .NET logging with configurable log levels in `appsettings.json`.

## Testing
Use the Swagger UI at the root URL to test all endpoints interactively.
