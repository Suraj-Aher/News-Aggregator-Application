using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NewsPortal.API.Data;
using NewsPortal.API.DTOs;
using NewsPortal.API.Models;

namespace NewsPortal.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")]
    public class UsersController : ControllerBase
    {
        private readonly NewsPortalDbContext _context;
        private readonly ILogger<UsersController> _logger;
        
        public UsersController(NewsPortalDbContext context, ILogger<UsersController> logger)
        {
            _context = context;
            _logger = logger;
        }
        
        /// <summary>
        /// Get all users (Admin only)
        /// </summary>
        /// <returns>List of users</returns>
        [HttpGet]
        public async Task<ActionResult<List<UserDto>>> GetAllUsers()
        {
            try
            {
                var users = await _context.Users
                    .Where(u => u.IsActive)
                    .Select(u => new UserDto
                    {
                        Id = u.Id,
                        Username = u.Username,
                        Email = u.Email,
                        FirstName = u.FirstName,
                        LastName = u.LastName,
                        Role = u.Role,
                        CreatedAt = u.CreatedAt,
                        IsActive = u.IsActive
                    })
                    .OrderBy(u => u.Username)
                    .ToListAsync();
                    
                return Ok(users);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting users");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
        
        /// <summary>
        /// Get user by ID (Admin only)
        /// </summary>
        /// <param name="id">User ID</param>
        /// <returns>User details</returns>
        [HttpGet("{id}")]
        public async Task<ActionResult<UserDto>> GetUserById(int id)
        {
            try
            {
                var user = await _context.Users
                    .Where(u => u.Id == id && u.IsActive)
                    .Select(u => new UserDto
                    {
                        Id = u.Id,
                        Username = u.Username,
                        Email = u.Email,
                        FirstName = u.FirstName,
                        LastName = u.LastName,
                        Role = u.Role,
                        CreatedAt = u.CreatedAt,
                        IsActive = u.IsActive
                    })
                    .FirstOrDefaultAsync();
                    
                if (user == null)
                {
                    return NotFound(new { message = "User not found" });
                }
                
                return Ok(user);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting user by ID: {UserId}", id);
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
        
        /// <summary>
        /// Update user (Admin only)
        /// </summary>
        /// <param name="id">User ID</param>
        /// <param name="updateDto">User update data</param>
        /// <returns>Updated user</returns>
        [HttpPut("{id}")]
        public async Task<ActionResult<UserDto>> UpdateUser(int id, UpdateUserDto updateDto)
        {
            try
            {
                var user = await _context.Users
                    .FirstOrDefaultAsync(u => u.Id == id && u.IsActive);
                    
                if (user == null)
                {
                    return NotFound(new { message = "User not found" });
                }
                
                // Update user properties
                if (!string.IsNullOrEmpty(updateDto.FirstName))
                    user.FirstName = updateDto.FirstName;
                    
                if (!string.IsNullOrEmpty(updateDto.LastName))
                    user.LastName = updateDto.LastName;
                    
                if (!string.IsNullOrEmpty(updateDto.Role))
                    user.Role = updateDto.Role;
                    
                user.UpdatedAt = DateTime.UtcNow;
                
                await _context.SaveChangesAsync();
                
                var userDto = new UserDto
                {
                    Id = user.Id,
                    Username = user.Username,
                    Email = user.Email,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Role = user.Role,
                    CreatedAt = user.CreatedAt,
                    IsActive = user.IsActive
                };
                
                _logger.LogInformation("User {UserId} updated successfully", id);
                return Ok(userDto);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating user: {UserId}", id);
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
        
        /// <summary>
        /// Deactivate user (Admin only)
        /// </summary>
        /// <param name="id">User ID</param>
        /// <returns>Success message</returns>
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeactivateUser(int id)
        {
            try
            {
                var user = await _context.Users
                    .FirstOrDefaultAsync(u => u.Id == id && u.IsActive);
                    
                if (user == null)
                {
                    return NotFound(new { message = "User not found" });
                }
                
                // Don't allow deactivating the current admin user
                var currentUserId = User.FindFirst("userId")?.Value;
                if (currentUserId == id.ToString())
                {
                    return BadRequest(new { message = "Cannot deactivate your own account" });
                }
                
                user.IsActive = false;
                user.UpdatedAt = DateTime.UtcNow;
                
                await _context.SaveChangesAsync();
                
                _logger.LogInformation("User {UserId} deactivated successfully", id);
                return Ok(new { message = "User deactivated successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deactivating user: {UserId}", id);
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
        
        /// <summary>
        /// Get user statistics (Admin only)
        /// </summary>
        /// <returns>User statistics</returns>
        [HttpGet("stats")]
        public async Task<ActionResult<UserStatsDto>> GetUserStats()
        {
            try
            {
                var totalUsers = await _context.Users.CountAsync(u => u.IsActive);
                var adminUsers = await _context.Users.CountAsync(u => u.IsActive && u.Role == "Admin");
                var regularUsers = await _context.Users.CountAsync(u => u.IsActive && u.Role == "User");
                var usersToday = await _context.Users.CountAsync(u => u.IsActive && u.CreatedAt.Date == DateTime.UtcNow.Date);
                var usersThisWeek = await _context.Users.CountAsync(u => u.IsActive && u.CreatedAt >= DateTime.UtcNow.AddDays(-7));
                
                var stats = new UserStatsDto
                {
                    TotalUsers = totalUsers,
                    AdminUsers = adminUsers,
                    RegularUsers = regularUsers,
                    UsersToday = usersToday,
                    UsersThisWeek = usersThisWeek
                };
                
                return Ok(stats);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting user statistics");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
    }
}
