using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NewsPortal.API.DTOs;
using NewsPortal.API.Services;

namespace NewsPortal.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class NewsController : ControllerBase
    {
        private readonly INewsService _newsService;
        private readonly ILogger<NewsController> _logger;
        
        public NewsController(INewsService newsService, ILogger<NewsController> logger)
        {
            _newsService = newsService;
            _logger = logger;
        }
        
        /// <summary>
        /// Get news articles with filtering and pagination
        /// </summary>
        /// <param name="categoryId">Filter by category ID</param>
        /// <param name="categoryName">Filter by category name</param>
        /// <param name="language">Filter by language</param>
        /// <param name="country">Filter by country</param>
        /// <param name="query">Search query</param>
        /// <param name="fromDate">Filter from date</param>
        /// <param name="toDate">Filter to date</param>
        /// <param name="page">Page number (default: 1)</param>
        /// <param name="pageSize">Page size (default: 10)</param>
        /// <returns>Paginated news articles</returns>
        [HttpGet]
        public async Task<ActionResult<NewsResponseDto>> GetNews(
            [FromQuery] int? categoryId = null,
            [FromQuery] string? categoryName = null,
            [FromQuery] string? language = null,
            [FromQuery] string? country = null,
            [FromQuery] string? query = null,
            [FromQuery] DateTime? fromDate = null,
            [FromQuery] DateTime? toDate = null,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 10)
        {
            try
            {
                if (page < 1) page = 1;
                if (pageSize < 1 || pageSize > 100) pageSize = 10;
                
                var filter = new NewsFilterDto
                {
                    CategoryId = categoryId,
                    CategoryName = categoryName,
                    Language = language,
                    Country = country,
                    Query = query,
                    FromDate = fromDate,
                    ToDate = toDate,
                    Page = page,
                    PageSize = pageSize
                };
                
                var result = await _newsService.GetNewsAsync(filter);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting news");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
        
        /// <summary>
        /// Get a specific news article by ID
        /// </summary>
        /// <param name="id">News article ID</param>
        /// <returns>News article details</returns>
        [HttpGet("{id}")]
        public async Task<ActionResult<NewsArticleDto>> GetNewsById(int id)
        {
            try
            {
                var article = await _newsService.GetNewsByIdAsync(id);
                
                if (article == null)
                {
                    return NotFound(new { message = "News article not found" });
                }
                
                return Ok(article);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting news article with ID: {id}");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
        
        /// <summary>
        /// Search news articles
        /// </summary>
        /// <param name="q">Search query</param>
        /// <param name="page">Page number (default: 1)</param>
        /// <param name="pageSize">Page size (default: 10)</param>
        /// <returns>Search results</returns>
        [HttpGet("search")]
        public async Task<ActionResult<NewsResponseDto>> SearchNews(
            [FromQuery] string q,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 10)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(q))
                {
                    return BadRequest(new { message = "Search query is required" });
                }
                
                if (page < 1) page = 1;
                if (pageSize < 1 || pageSize > 100) pageSize = 10;
                
                var result = await _newsService.SearchNewsAsync(q, page, pageSize);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error searching news");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
        
        /// <summary>
        /// Get available news categories
        /// </summary>
        /// <returns>List of available categories</returns>
        [HttpGet("categories")]
        public async Task<ActionResult<List<string>>> GetCategories()
        {
            try
            {
                var categories = await _newsService.GetAvailableCategoriesAsync();
                return Ok(categories);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting categories");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
        
        /// <summary>
        /// Sync news from external API (Admin only)
        /// </summary>
        /// <param name="category">Specific category to sync (optional)</param>
        /// <returns>Sync result</returns>
        [HttpPost("sync")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult> SyncNews([FromQuery] string? category = null)
        {
            try
            {
                var result = await _newsService.SyncNewsFromExternalApiAsync(category);
                
                if (result)
                {
                    _logger.LogInformation($"News sync completed for category: {category ?? "all"}");
                    return Ok(new { message = "News sync completed successfully" });
                }
                else
                {
                    return StatusCode(500, new { message = "News sync failed" });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error syncing news");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        /// <summary>
        /// Get dashboard statistics (Admin only)
        /// </summary>
        /// <returns>Dashboard statistics</returns>
        [HttpGet("dashboard-stats")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<DashboardStatsDto>> GetDashboardStats()
        {
            try
            {
                var stats = await _newsService.GetDashboardStatsAsync();
                return Ok(stats);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting dashboard statistics");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }

        /// <summary>
        /// Health check endpoint
        /// </summary>
        /// <returns>API health status</returns>
        [HttpGet("health")]
        public ActionResult GetHealth()
        {
            return Ok(new 
            { 
                status = "healthy", 
                timestamp = DateTime.UtcNow,
                version = "1.0.0"
            });
        }

        /// <summary>
        /// Seed sample Indian news articles for demonstration
        /// </summary>
        [HttpPost("seed-indian-news")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult> SeedIndianNews()
        {
            try
            {
                var result = await _newsService.SeedIndianNewsAsync();
                if (result)
                {
                    return Ok(new { message = "Indian news articles seeded successfully" });
                }
                return BadRequest(new { message = "Failed to seed Indian news articles" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error seeding Indian news");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
    }
}
