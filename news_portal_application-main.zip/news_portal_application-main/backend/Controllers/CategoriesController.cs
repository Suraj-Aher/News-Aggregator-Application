using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NewsPortal.API.Data;
using NewsPortal.API.DTOs;
using NewsPortal.API.Models;

namespace NewsPortal.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CategoriesController : ControllerBase
    {
        private readonly NewsPortalDbContext _context;
        private readonly ILogger<CategoriesController> _logger;
        
        public CategoriesController(NewsPortalDbContext context, ILogger<CategoriesController> logger)
        {
            _context = context;
            _logger = logger;
        }
        
        /// <summary>
        /// Get all categories with article counts
        /// </summary>
        /// <returns>List of categories</returns>
        [HttpGet]
        public async Task<ActionResult<List<CategoryDto>>> GetCategories()
        {
            try
            {
                var categories = await _context.Categories
                    .Where(c => c.IsActive)
                    .Select(c => new CategoryDto
                    {
                        Id = c.Id,
                        Name = c.Name,
                        Slug = c.Slug,
                        Description = c.Description,
                        Icon = c.Icon,
                        Color = c.Color,
                        ArticleCount = 0, // We'll implement this later when CategoryId is added to NewsArticles
                        CreatedAt = c.CreatedAt,
                        UpdatedAt = c.UpdatedAt,
                        IsActive = c.IsActive
                    })
                    .OrderBy(c => c.Name)
                    .ToListAsync();
                    
                return Ok(categories);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting categories");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
        
        /// <summary>
        /// Get a single category by ID
        /// </summary>
        /// <param name="id">Category ID</param>
        /// <returns>Category details</returns>
        [HttpGet("{id}")]
        public async Task<ActionResult<CategoryDto>> GetCategory(int id)
        {
            try
            {
                var category = await _context.Categories
                    .Where(c => c.Id == id && c.IsActive)
                    .Select(c => new CategoryDto
                    {
                        Id = c.Id,
                        Name = c.Name,
                        Slug = c.Slug,
                        Description = c.Description,
                        Icon = c.Icon,
                        Color = c.Color,
                        ArticleCount = 0, // We'll implement this later when CategoryId is added to NewsArticles
                        CreatedAt = c.CreatedAt,
                        UpdatedAt = c.UpdatedAt,
                        IsActive = c.IsActive
                    })
                    .FirstOrDefaultAsync();
                    
                if (category == null)
                {
                    return NotFound(new { message = "Category not found" });
                }
                    
                return Ok(category);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting category {CategoryId}", id);
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
        
        /// <summary>
        /// Create a new category (Admin only)
        /// </summary>
        /// <param name="createDto">Category creation data</param>
        /// <returns>Created category</returns>
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<CategoryDto>> CreateCategory(CreateCategoryDto createDto)
        {
            try
            {
                // Check if category already exists
                var existingCategory = await _context.Categories
                    .AnyAsync(c => c.Name.ToLower() == createDto.Name.ToLower());
                    
                if (existingCategory)
                {
                    return BadRequest(new { message = "Category already exists" });
                }

                // Generate slug from name
                var slug = createDto.Name.ToLower()
                    .Replace(" ", "-")
                    .Replace("&", "and")
                    .Replace(",", "")
                    .Replace(".", "");

                var category = new Category
                {
                    Name = createDto.Name,
                    Slug = slug,
                    Description = createDto.Description ?? $"Articles related to {createDto.Name}",
                    Icon = createDto.Icon,
                    Color = createDto.Color ?? "#6366F1",
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow,
                    IsActive = true
                };

                _context.Categories.Add(category);
                await _context.SaveChangesAsync();

                var categoryDto = new CategoryDto
                {
                    Id = category.Id,
                    Name = category.Name,
                    Slug = category.Slug,
                    Description = category.Description,
                    Icon = category.Icon,
                    Color = category.Color,
                    ArticleCount = 0,
                    CreatedAt = category.CreatedAt,
                    UpdatedAt = category.UpdatedAt,
                    IsActive = category.IsActive
                };
                
                _logger.LogInformation("Category {CategoryName} created successfully", createDto.Name);
                return CreatedAtAction(nameof(GetCategories), categoryDto);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating category");
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
        
        /// <summary>
        /// Update category (Admin only)
        /// </summary>
        /// <param name="id">Category ID</param>
        /// <param name="updateDto">Category update data</param>
        /// <returns>Updated category</returns>
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<CategoryDto>> UpdateCategory(int id, UpdateCategoryDto updateDto)
        {
            try
            {
                // Find the category
                var category = await _context.Categories.FindAsync(id);
                    
                if (category == null)
                {
                    return NotFound(new { message = "Category not found" });
                }

                // Check if another category with the same name exists (excluding current category)
                var existingCategory = await _context.Categories
                    .AnyAsync(c => c.Name.ToLower() == updateDto.Name.ToLower() && c.Id != id);
                    
                if (existingCategory)
                {
                    return BadRequest(new { message = "Category with this name already exists" });
                }

                // Update category properties
                category.Name = updateDto.Name;
                category.Slug = updateDto.Name.ToLower()
                    .Replace(" ", "-")
                    .Replace("&", "and")
                    .Replace(",", "")
                    .Replace(".", "");
                category.Description = updateDto.Description;
                category.Icon = updateDto.Icon;
                category.Color = updateDto.Color;
                category.IsActive = updateDto.IsActive;
                category.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                var categoryDto = new CategoryDto
                {
                    Id = category.Id,
                    Name = category.Name,
                    Slug = category.Slug,
                    Description = category.Description,
                    Icon = category.Icon,
                    Color = category.Color,
                    ArticleCount = 0, // We'll implement this later when CategoryId is added to NewsArticles
                    CreatedAt = category.CreatedAt,
                    UpdatedAt = category.UpdatedAt,
                    IsActive = category.IsActive
                };
                
                _logger.LogInformation("Category {CategoryId} updated successfully", id);
                return Ok(categoryDto);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating category: {CategoryId}", id);
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
        
        /// <summary>
        /// Delete category (Admin only)
        /// </summary>
        /// <param name="id">Category ID to delete</param>
        /// <returns>Success message</returns>
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult> DeleteCategory(int id)
        {
            try
            {
                var category = await _context.Categories.FindAsync(id);
                    
                if (category == null)
                {
                    return NotFound(new { message = "Category not found" });
                }

                // Check if there are any articles using this category
                // For now, we'll just soft delete by setting IsActive to false
                // Later when CategoryId is added to NewsArticles, we can add proper validation
                
                category.IsActive = false;
                category.UpdatedAt = DateTime.UtcNow;
                
                await _context.SaveChangesAsync();
                
                _logger.LogInformation("Category {CategoryId} soft deleted successfully", id);
                    
                return Ok(new { 
                    message = "Category deleted successfully" 
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting category: {CategoryId}", id);
                return StatusCode(500, new { message = "Internal server error" });
            }
        }
    }
}
